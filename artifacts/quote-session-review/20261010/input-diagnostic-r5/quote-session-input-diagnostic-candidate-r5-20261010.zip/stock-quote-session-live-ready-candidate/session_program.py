"""SESSION consumer: existing r2 paper engine unchanged, SQL-atomic sequence acknowledgments."""

import asyncio
import json
import signal
import sqlite3
from pathlib import Path

import demo
import quote_paper_runtime as engine
import quote_session as session

MODE = "QUOTE_SESSION_PAPER_UNVALIDATED"


def binding(manifest, path):
    return {
        key: manifest[key]
        for key in (
            "session_id",
            "started_at",
            "deadline_at",
            "profile",
            "producer_sha256",
            "input_kind",
        )
    } | {
        "manifest": str(path.absolute()),
        "consumer_sha256": session.digest(Path(__file__).read_bytes()),
    }


def summary(root):
    path = root / "quote-paper.db"
    if not path.exists():
        return engine.initial_wallet(), None, []
    conn = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("BEGIN")
        wallet = engine.replay(conn)
        tables = {
            r[0]
            for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        if "session_binding" not in tables:
            session.require(wallet["processed_captures"] == 0, "SESSION_FOREIGN_LEDGER")
            return wallet, None, []
        record = conn.execute("SELECT payload FROM session_binding").fetchone()
        if record is None:
            session.require(wallet["processed_captures"] == 0, "SESSION_FOREIGN_LEDGER")
            return wallet, None, []
        bound = json.loads(record[0])
        committed = [
            dict(row)
            for row in conn.execute("SELECT * FROM session_commits ORDER BY sequence")
        ]
        session.require(
            len(committed) == wallet["processed_captures"],
            "SESSION_LEDGER_CURSOR_MISMATCH",
        )
        for index, row in enumerate(committed, 1):
            session.require(row["sequence"] == index, "SESSION_LEDGER_SEQUENCE_INVALID")
            cycle = conn.execute(
                "SELECT event_sha256 FROM quote_paper_cycles WHERE capture_sha256=?",
                (row["capture_sha256"],),
            ).fetchone()
            session.require(
                cycle is not None and cycle[0] == row["event_sha256"],
                "SESSION_LEDGER_LINK_INVALID",
            )
        return wallet, bound, committed
    finally:
        conn.close()


def initialize(conn, bound):
    try:
        conn.executescript("""
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS session_binding(payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS session_links(sequence INTEGER PRIMARY KEY,capture_sha256 TEXT UNIQUE NOT NULL,
            receipt_sha256 TEXT NOT NULL,previous_receipt_sha256 TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS session_commits(sequence INTEGER PRIMARY KEY,capture_sha256 TEXT UNIQUE NOT NULL,
            receipt_sha256 TEXT NOT NULL,event_sha256 TEXT NOT NULL);
        CREATE TRIGGER IF NOT EXISTS session_cycle_gate BEFORE INSERT ON quote_paper_cycles BEGIN
          SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM session_links WHERE capture_sha256=NEW.capture_sha256
            AND sequence=(SELECT COALESCE(MAX(sequence),0)+1 FROM session_commits))
            THEN RAISE(ABORT,'SESSION_SEQUENCE_UNATTESTED') END;
        END;
        CREATE TRIGGER IF NOT EXISTS session_cycle_ack AFTER INSERT ON quote_paper_cycles BEGIN
          INSERT INTO session_commits SELECT sequence,capture_sha256,receipt_sha256,NEW.event_sha256
            FROM session_links WHERE capture_sha256=NEW.capture_sha256;
        END;
        """)
        rows = conn.execute("SELECT payload FROM session_binding").fetchall()
        if not rows:
            session.require(
                engine.replay(conn)["processed_captures"] == 0, "SESSION_FOREIGN_LEDGER"
            )
            conn.execute(
                "INSERT INTO session_binding VALUES(?)",
                (session.encode(bound).decode(),),
            )
        else:
            session.require(
                len(rows) == 1 and json.loads(rows[0][0]) == bound,
                "SESSION_BINDING_CHANGED",
            )
        for table in ("session_binding", "session_links", "session_commits"):
            for action in ("UPDATE", "DELETE"):
                conn.execute(
                    f"CREATE TRIGGER IF NOT EXISTS {table}_no_{action.lower()} BEFORE {action} ON {table} BEGIN SELECT RAISE(ABORT,'append-only'); END"
                )
        conn.commit()
    except BaseException:
        conn.rollback()
        raise


async def step(root, manifest_path, clock):
    sampled_now, sampled_mono = clock.now(), clock.monotonic()
    manifest, entries = session.read_session(manifest_path, sampled_now)
    started, deadline = (
        session.utc(manifest["started_at"]),
        session.utc(manifest["deadline_at"]),
    )
    remaining = (deadline - sampled_now).total_seconds()
    last_now, last_mono = sampled_now, sampled_mono

    def bounded_clock():
        nonlocal last_now, last_mono
        current = clock.now()
        monotonic = clock.monotonic()
        elapsed = monotonic - sampled_mono
        session.require(
            started <= last_now <= current < deadline
            and last_mono <= monotonic
            and 0 <= elapsed < remaining,
            "SESSION_CONSUMPTION_DEADLINE_OR_CLOCK",
        )
        last_now, last_mono = current, monotonic
        return current

    wallet, bound, commits = summary(root)
    expected = binding(manifest, manifest_path)
    session.require(bound is None or bound == expected, "SESSION_BINDING_CHANGED")
    cursor = len(commits)
    session.require(cursor <= len(entries), "SESSION_MANIFEST_ROLLBACK")
    for row, item in zip(commits, entries):
        session.require(
            row["capture_sha256"] == item["snapshot_sha256"]
            and row["receipt_sha256"] == item["receipt_sha256"],
            "SESSION_COMMITTED_PAIR_CHANGED",
        )
    if not entries:
        return dict(waiting=True, cursor=cursor, complete=False)
    # Check the latest input even when every sequence was already committed.
    session.verified_capture(entries[-1], bounded_clock)
    if cursor == len(entries):
        return dict(
            waiting=manifest["state"] == "ACTIVE",
            cursor=cursor,
            complete=manifest["state"] == "COMPLETED",
            duplicate=True,
        )
    item = entries[cursor]
    quotes, report = session.verified_capture(item, bounded_clock)
    runtime = engine.QuotePaperRuntime(root)
    try:
        initialize(runtime.conn, expected)
        proposal = (
            item["sequence"],
            item["snapshot_sha256"],
            item["receipt_sha256"],
            item["proof"]["previous_receipt_sha256"],
        )
        prior = runtime.conn.execute(
            "SELECT * FROM session_links WHERE sequence=?", (item["sequence"],)
        ).fetchone()
        if prior is None:
            runtime.conn.execute("INSERT INTO session_links VALUES(?,?,?,?)", proposal)
        else:
            session.require(tuple(prior) == proposal, "SESSION_PROPOSAL_CHANGED")
        result = await runtime.process(quotes, report, clock=bounded_clock)
        wallet, _, commits = summary(root)
        session.require(
            len(commits) == cursor + 1 and not result["duplicate_capture"],
            "SESSION_ACK_FAILED",
        )
        return dict(
            waiting=False,
            cursor=len(commits),
            complete=manifest["state"] == "COMPLETED" and len(commits) == len(entries),
            paper=wallet,
        )
    finally:
        runtime.close()


def own_root(root):
    saved = demo.lifecycle.read(root, "status.json") if root.exists() else None
    session.require(
        saved is None or saved.get("mode") == MODE, "FOREIGN_OPERATOR_STATE"
    )
    if saved is None:
        if (root / "quote-paper.db").exists():
            _, bound, _ = summary(root)
            session.require(
                bound is not None
                and bound["producer_sha256"] == session.pin()
                and bound["profile"] == session.PROFILE,
                "SESSION_FOREIGN_LEDGER",
            )


def status(root, manifest_path=None, *, clock=None):
    own_root(root)
    clock = clock or session.Clock()
    state = demo.lifecycle.status(root, mode=MODE)
    state.pop("last_result", None)
    try:
        wallet, bound, commits = summary(root)
    except (sqlite3.Error, TypeError):
        raise demo.DataError("SESSION_LEDGER_UNAVAILABLE") from None
    path = manifest_path or (Path(bound["manifest"]) if bound else None)
    quotes = {}
    report = dict(phase="BLOCKED", reason="SESSION_INPUT_NOT_BOUND", prices_USD={})
    if path is not None:
        try:
            manifest, entries = session.read_session(path, clock.now())
            session.require(
                bound is None or bound == binding(manifest, path),
                "SESSION_BINDING_CHANGED",
            )
            if entries:
                quotes, report = session.verified_capture(entries[-1], clock.now)
        except Exception:
            report = dict(
                phase="BLOCKED", reason="SESSION_INPUT_REJECTED", prices_USD={}
            )
    if state.get("phase") in ("INPUT_BLOCKED", "BOUNDED_END", "INTERRUPTED"):
        quotes = {}
        report = dict(
            phase="BLOCKED",
            reason=state.get("last_error", "SESSION_CONSUMER_STOPPED"),
            prices_USD={},
        )
    wallet["current_snapshot_equity_USD"] = (
        str(
            sum(
                wallet["positions"].get(s, 0) * q.last_price_usd
                for s, q in quotes.items()
            )
            + engine.Decimal(wallet["cash_USD"])
        )
        if quotes
        else None
    )
    return dict(
        state,
        paper=wallet,
        session_cursor=len(commits),
        quote_input=report,
        holding=engine.holding_status(wallet, clock.now()),
        broker_orders_enabled=False,
        orders_submitted=0,
        strategy_validated=False,
        live_eligible=False,
        strategy_trials_added=0,
        input_kind="INVENTED_SYNTHETIC_ONLY",
        notice="수익성 미검증 네 현재가 연결용 / 합성 SESSION 후보",
    )


async def start(root, path, *, clock=None):
    own_root(root)
    clock = clock or session.Clock()
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)
    began = clock.monotonic()
    with demo.lifecycle.lock(root, "control.lock", blocking=True):
        owner = demo.lifecycle.lock(root, "operator.lock")
        acquired = owner.__enter__()
        if not acquired:
            owner.__exit__(None, None, None)
            return dict(phase="ALREADY_RUNNING", orders_submitted=0)
    state = dict(
        mode=MODE,
        phase="RUNNING",
        run_id=session.uuid.uuid4().hex,
        orders_submitted=0,
        cycles_completed=0,
    )

    def save(phase, **extra):
        state.update(phase=phase, updated_at=clock.now().isoformat(), **extra)
        demo.lifecycle.record_event(root, state)
        demo.lifecycle.publish(root, "status.json", state)

    try:
        save("RUNNING")
        async with asyncio.timeout(175):
            while True:
                if (
                    stop.is_set()
                    or (demo.lifecycle.read(root, "stop.json") or {}).get("run_id")
                    == state["run_id"]
                ):
                    save("STOPPED")
                    break
                if not 0 <= clock.monotonic() - began < 175:
                    save("BOUNDED_END")
                    break
                result = await step(root, path, clock)
                save("RUNNING", cycles_completed=result["cursor"])
                if result["complete"]:
                    save("COMPLETED")
                    break
                if result.get("waiting"):
                    await clock.sleep(1)
    except TimeoutError:
        save("BOUNDED_END")
    except Exception as error:
        reason = (
            str(error) if isinstance(error, demo.DataError) else "SESSION_INPUT_INVALID"
        )
        save("INPUT_BLOCKED", last_error=reason)
    finally:
        owner.__exit__(None, None, None)
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.remove_signal_handler(sig)
    return status(root, path, clock=clock)


def stop(root):
    own_root(root)
    return dict(
        demo.lifecycle.request_stop(root),
        orders_submitted=0,
        stop_behavior="PAUSE_PRESERVE_POSITIONS_NOT_LIQUIDATION",
    )
