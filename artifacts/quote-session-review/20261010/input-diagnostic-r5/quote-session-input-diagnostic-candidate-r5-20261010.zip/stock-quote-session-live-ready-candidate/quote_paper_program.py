"""Verified quote file -> fixed unvalidated policy -> existing virtual order ledger."""

from __future__ import annotations

import argparse
import asyncio
import json
import signal
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

import demo
import quote_input_runner as inputs
from quote_paper_runtime import QuotePaperRuntime, holding_status, read_wallet, regular_session

ROOT = Path(__file__).resolve().parent
MODE = 'QUOTE_PAPER_PLUMBING_UNVALIDATED'


def require_own_root(root):
    saved = demo.lifecycle.read(root, 'status.json') if root.exists() else None
    inputs.require(saved is None or saved.get('mode') == MODE, 'FOREIGN_OPERATOR_STATE')


def status(root, *, clock=lambda: datetime.now(UTC)):
    require_own_root(root)
    state = demo.lifecycle.status(root, mode=MODE)
    state.pop('last_result', None)
    now = clock()
    wallet = read_wallet(root / 'quote-paper.db')
    binding = demo.lifecycle.read(root, 'input.json') if root.exists() else None
    quotes = {}
    try:
        inputs.require(binding is not None, 'CAPTURE_INPUT_NOT_BOUND')
        quotes, report = inputs.verified_quotes(Path(binding['snapshot']), Path(binding['receipt']), clock=clock)
    except demo.DataError as error:
        report = dict(phase='BLOCKED', reason=str(error), prices_USD={}, accepted_symbols=[])
    holding = holding_status(wallet, now)
    wallet['current_snapshot_equity_USD'] = (str(sum(wallet['positions'].get(s, 0) * q.last_price_usd
                                                    for s, q in quotes.items())
                                                + Decimal(wallet['cash_USD']))
                                            if quotes else None)
    wallet['valuation_basis'] = 'RESPONSE_LAST_NOT_CONFIRMED_EXECUTABLE_PRICE' if quotes else 'UNKNOWN_INPUT_BLOCKED'
    if state.get('last_error') and not state.get('running'):
        state['phase'] = 'INPUT_BLOCKED'
    return dict(state, quote_input=report, paper=wallet, holding=holding, session=regular_session(now),
                strategy_uses_quotes=True, strategy_validated=False,
                policy_purpose='EXECUTION_PLUMBING_ONLY_UNVALIDATED',
                OHLCV_constructed=False, actual_capture_connection_verified=False,
                market_connection_verified=False, real_time_verified=False,
                live_eligible=False, broker_orders_enabled=False,
                stop_behavior='PAUSE_PRESERVE_POSITIONS_NOT_LIQUIDATION',
                strategy_trials_added=0,
                research_inventory=dict(local_prior_lower_bound=63,
                                        project_latest_lower_bound_not_established_here=True,
                                        parent_reported_parallel_lower_bound=82))


async def start(root, snapshot, receipt, *, cycles=0, clock=lambda: datetime.now(UTC)):
    require_own_root(root)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    async def cycle():
        runtime = None
        try:
            quotes, report = inputs.verified_quotes(snapshot, receipt, clock=clock)
            binding = dict(snapshot=str(snapshot.absolute()), receipt=str(receipt.absolute()))
            prior = demo.lifecycle.read(root, 'input.json')
            inputs.require(prior is None or prior == binding, 'INPUT_BINDING_CHANGED_USE_SEPARATE_ROOT')
            if prior is None:
                demo.lifecycle.publish(root, 'input.json', binding)
            runtime = QuotePaperRuntime(root)
            return dict(await runtime.process(quotes, report, clock=clock), orders_submitted=0)
        except Exception:
            stop.set()  # No retry and no previous price fallback.
            raise
        finally:
            if runtime is not None:
                runtime.close()

    try:
        result = await demo.lifecycle.run(root, cycle=cycle, cycles=cycles, poll_seconds=60,
                                          stop_event=stop, mode=MODE)
        if result['phase'] == 'ALREADY_RUNNING':
            return result
        return status(root, clock=clock)
    finally:
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.remove_signal_handler(sig)


def stop(root):
    require_own_root(root)
    return dict(demo.lifecycle.request_stop(root), mode=MODE,
                stop_behavior='PAUSE_PRESERVE_POSITIONS_NOT_LIQUIDATION')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('start', 'status', 'stop'))
    parser.add_argument('--root', type=Path, default=ROOT / 'paper-quote-state')
    parser.add_argument('--snapshot', type=Path)
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--cycles', type=int, default=0)
    args = parser.parse_args()
    try:
        with demo.deny_network():
            if args.command == 'start':
                inputs.require(args.snapshot is not None and args.receipt is not None,
                               'CAPTURE_SNAPSHOT_AND_RECEIPT_REQUIRED')
                result = asyncio.run(start(args.root, args.snapshot, args.receipt, cycles=args.cycles))
            elif args.command == 'stop':
                result = stop(args.root)
            else:
                result = status(args.root)
    except demo.DataError as error:
        result = dict(phase='INPUT_BLOCKED', reason=str(error))
    except Exception:
        result = dict(phase='INPUT_BLOCKED', reason='QUOTE_PAPER_PROGRAM_FAILED')
    result.update(orders_submitted=0, strategy_validated=False, live_eligible=False,
                  notice='네 현재가의 모의 주문 연결 / 미검증 고정 정책 / 실제 시세 연결 아직 미확인')
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    return 2 if result.get('phase') in {'INPUT_BLOCKED', 'FAILED', 'ALREADY_RUNNING'} else 0


if __name__ == '__main__':
    raise SystemExit(main())
