"""Process-local network refusal for the dedicated offline command only."""

import socket
from contextlib import contextmanager


def _denied(*args, **kwargs):
    raise RuntimeError("OFFLINE_NETWORK_DENIED")


@contextmanager
def deny_network():
    originals = [
        (socket.socket, "connect", socket.socket.connect),
        (socket.socket, "connect_ex", socket.socket.connect_ex),
        (socket.socket, "sendto", socket.socket.sendto),
        (socket, "getaddrinfo", socket.getaddrinfo),
    ]
    try:
        for owner, name, _ in originals:
            setattr(owner, name, _denied)
        yield
    finally:
        for owner, name, original in originals:
            setattr(owner, name, original)
