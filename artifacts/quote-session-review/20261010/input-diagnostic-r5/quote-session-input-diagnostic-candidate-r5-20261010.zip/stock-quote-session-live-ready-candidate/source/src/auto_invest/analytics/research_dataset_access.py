"""Repository research access contract; metadata first, numeric prices second.

This is an application guard, not a filesystem sandbox or a new research budget.
Unknown real research inputs and experiments have no implicit permission.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

LEDGER_PATH = Path(__file__).resolve().parents[3] / (
    "specs/190-cost-aware-intraday/contracts/dataset-access-ledger.json"
)
_NEW_YORK = ZoneInfo("America/New_York")


class ResearchAccessError(ValueError):
    """Input is not authorized for this experiment and purpose."""


@dataclass(frozen=True)
class ResearchReadPermit:
    experiment: str
    first_session: date
    last_session: date

    def check_timestamp(self, moment: datetime) -> None:
        session = moment.astimezone(_NEW_YORK).date()
        if not self.first_session <= session <= self.last_session:
            raise ResearchAccessError(
                f"protected research row denied before price parsing: "
                f"{self.experiment}:{session.isoformat()}"
            )


def research_preflight(
    manifest: Mapping[str, Any], manifest_bytes: bytes, experiment: str | None,
) -> ResearchReadPermit | None:
    """Check metadata before any CSV open/hash; return the row-level boundary.

    Unrelated operational inputs retain their existing loader contract. Historical
    HF/PiTrading research inputs require a context even through the shared loader.
    Synthetic fixtures remain unusable as promotion evidence in existing engines.
    """
    dataset_id = str(manifest.get("dataset_id", ""))
    provider = str(manifest.get("provider", ""))
    historical_hf = dataset_id.casefold().startswith("hf-") or any(
        marker in provider.casefold() for marker in ("hf data library", "pitrading")
    )
    if experiment is None and not historical_hf:
        return None
    ledger = json.loads(LEDGER_PATH.read_text(encoding="utf-8"))
    if ledger.get("schema_version") != "1.0":
        raise ResearchAccessError("research access ledger schema mismatch")
    profiles = ledger["experiments"]
    if experiment not in profiles:
        raise ResearchAccessError(
            "explicit registered research experiment required before CSV read"
        )
    if manifest.get("synthetic") is True and not historical_hf:
        return None
    digest = hashlib.sha256(manifest_bytes).hexdigest()
    profile = profiles[experiment]
    grants = profile["existing_development_read_grants"]
    matching = [grant for grant in grants if grant["manifest_sha256"] == digest]
    if len(matching) != 1:
        raise ResearchAccessError(
            f"real research input denied before CSV read: {experiment}; "
            "no unique existing development grant (confirmation/reuse requires review)"
        )
    grant = matching[0]
    source = ledger["sources"][grant["source_id"]]
    first, last = source["first_session"], source["last_session"]
    if (grant["first_session"], grant["last_session"]) != (first, last):
        # A shared full-file reader must not hash a source extending beyond a
        # study-specific boundary. A separately registered prefix is required.
        raise ResearchAccessError("source span exceeds experiment grant before CSV read")
    return ResearchReadPermit(experiment, date.fromisoformat(first), date.fromisoformat(last))
