"""Search-wide overfitting statistics for the autonomous strategy factory."""

from __future__ import annotations

import itertools
import math
from collections.abc import Callable, Sequence
from decimal import Decimal

import numpy as np

from auto_invest.backtest.data_model import canonicalise_decimal


def _decimal(value: float) -> Decimal:
    return Decimal(canonicalise_decimal(value))


def annualized_sharpe(returns: Sequence[float], *, periods_per_year: int = 12) -> float:
    values = np.asarray(returns, dtype=np.float64)
    if values.size < 2:
        return 0.0
    std = float(np.std(values, ddof=1))
    if std <= 0.0:
        return 0.0
    return float(np.mean(values)) / std * math.sqrt(periods_per_year)


def probabilistic_sharpe(
    returns: Sequence[float],
    *,
    benchmark_sharpe_annual: float = 0.0,
    periods_per_year: int = 12,
) -> Decimal | None:
    values = np.asarray(returns, dtype=np.float64)
    if values.size < 2:
        return None
    std = float(np.std(values, ddof=1))
    if std <= 0.0:
        return None
    mean = float(np.mean(values))
    centered = values - mean
    m2 = float(np.mean(centered**2))
    if m2 <= 0.0:
        return None
    skew = float(np.mean(centered**3)) / (m2**1.5)
    kurt = float(np.mean(centered**4)) / (m2**2)
    observed = mean / std
    benchmark = benchmark_sharpe_annual / math.sqrt(periods_per_year)
    variance = 1.0 - skew * observed + ((kurt - 1.0) / 4.0) * observed**2
    if variance <= 0.0:
        variance = 1.0 + 0.5 * observed**2
    z = (observed - benchmark) * math.sqrt(values.size - 1) / math.sqrt(variance)
    return _decimal(0.5 * math.erfc(-z / math.sqrt(2.0)))


def effective_independent_trials(
    trial_returns: Sequence[Sequence[float]],
) -> Decimal:
    """Estimate independent trials from average within-family return correlation.

    Bailey and Lopez de Prado's DSR uses independent trials, not the raw count of
    correlated parameter variants. Invalid or non-positive dependence falls back
    to the raw count, which is the conservative fail-closed choice.
    """

    matrix = np.asarray(trial_returns, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[0] < 1 or matrix.shape[1] < 2:
        raise ValueError("trial returns must be an aligned two-dimensional matrix")
    raw_count = int(matrix.shape[0])
    if raw_count == 1:
        return _decimal(1.0)
    if np.any(np.std(matrix, axis=1) <= 0.0):
        return _decimal(float(raw_count))
    correlations = np.corrcoef(matrix)
    off_diagonal = correlations[np.triu_indices(raw_count, 1)]
    if off_diagonal.size == 0 or not np.all(np.isfinite(off_diagonal)):
        return _decimal(float(raw_count))
    average = float(np.mean(off_diagonal))
    if average <= 0.0:
        return _decimal(float(raw_count))
    average = min(1.0, average)
    implied = average + (1.0 - average) * raw_count
    return _decimal(max(1.0, min(float(raw_count), implied)))


def expected_max_sharpe_from_trials(
    trial_sharpes: Sequence[float],
    *,
    effective_trial_count: Decimal | float | None = None,
) -> float:
    values = np.asarray(trial_sharpes, dtype=np.float64)
    if values.size < 2:
        return 0.0
    std = float(np.std(values, ddof=1))
    if std <= 0.0:
        return 0.0
    n = float(values.size if effective_trial_count is None else effective_trial_count)
    if n < 1.0 or n > float(values.size):
        raise ValueError("effective trial count must be within the raw trial count")
    if n <= 1.0:
        return 0.0
    # Stable normal quantiles through Python's NormalDist.
    from statistics import NormalDist

    normal = NormalDist()
    gamma = 0.5772156649015329
    return std * (
        (1.0 - gamma) * normal.inv_cdf(1.0 - 1.0 / n)
        + gamma * normal.inv_cdf(1.0 - 1.0 / (n * math.e))
    )


def deflated_sharpe_from_trials(
    selected_returns: Sequence[float],
    trial_sharpes: Sequence[float],
    *,
    periods_per_year: int = 12,
    effective_trial_count: Decimal | float | None = None,
) -> Decimal | None:
    return probabilistic_sharpe(
        selected_returns,
        benchmark_sharpe_annual=expected_max_sharpe_from_trials(
            trial_sharpes,
            effective_trial_count=effective_trial_count,
        ),
        periods_per_year=periods_per_year,
    )


def probability_of_backtest_overfitting(
    segment_scores_by_trial: Sequence[Sequence[float]],
) -> Decimal | None:
    """Legacy segment-score diagnostic, with both split directions evaluated.

    Averaging precomputed segment Sharpes does not reproduce pooled-return
    selection. Use cscv_pbo_from_returns for a research acceptance gate.
    """

    matrix = np.asarray(segment_scores_by_trial, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[0] < 2 or matrix.shape[1] < 4:
        return None
    trials, segments = matrix.shape
    if segments % 2 or not np.all(np.isfinite(matrix)):
        return None
    half = segments // 2
    lower_half = 0
    evaluated = 0
    all_indexes = tuple(range(segments))
    for is_indexes in itertools.combinations(all_indexes, half):
        oos_indexes = tuple(index for index in all_indexes if index not in is_indexes)
        is_means = np.mean(matrix[:, is_indexes], axis=1)
        winner = int(np.argmax(is_means))
        oos_means = np.mean(matrix[:, oos_indexes], axis=1)
        winner_score = float(oos_means[winner])
        better = int(np.sum(oos_means > winner_score))
        # Worst rank among ties avoids awarding evidence from a tied flat curve.
        rank_from_top = better + int(np.sum(oos_means == winner_score))
        percentile_from_bottom = (trials - rank_from_top + 0.5) / trials
        if percentile_from_bottom <= 0.5:
            lower_half += 1
        evaluated += 1
    if evaluated == 0:
        return None
    return _decimal(lower_half / evaluated)


def cscv_design(observations: int, segments: int) -> dict[str, int | bool | str]:
    """Validate the equal-partition design without deleting or padding observations."""
    if (type(observations) is not int or type(segments) is not int
            or observations < 1 or segments < 4 or segments % 2):
        return {"valid": False, "reason": "invalid_observations_or_even_segments"}
    remainder = observations % segments
    return {"valid": remainder == 0 and observations // segments >= 2,
            "reason": "equal_partition" if remainder == 0 else "unequal_partition",
            "observations": observations, "segments": segments, "remainder": remainder,
            "segment_observations": observations // segments,
            "automatic_trimming_or_padding": False}


def cscv_pbo_from_returns(
    trial_returns: Sequence[Sequence[float]],
    *,
    segments: int,
    selector: Callable[[np.ndarray, tuple[int, ...]], int | None] | None = None,
    scorer: Callable[[Sequence[float]], float] | None = None,
) -> Decimal | None:
    """All CSCV directions, pooled daily Sharpe, exact IS selection callback.

    No truncation/padding, unequal chunks, nonfinite input, or unselected IS
    split can silently become a valid PBO. Callers must first verify identities,
    dates, units, cost model and complete search coverage. This statistic alone
    never certifies the global research program or independent confirmation.
    """
    matrix = np.asarray(trial_returns, dtype=np.float64)
    if (matrix.ndim != 2 or matrix.shape[0] < 2
            or not cscv_design(matrix.shape[1], segments)["valid"]
            or not np.all(np.isfinite(matrix))):
        return None
    groups = np.split(np.arange(matrix.shape[1]), segments)
    metric = scorer or (lambda row: annualized_sharpe(row, periods_per_year=252))
    failures = total = 0
    for chosen in itertools.combinations(range(segments), segments // 2):
        ins = tuple(int(i) for group in chosen for i in groups[group])
        outs = tuple(int(i) for group in range(segments) if group not in chosen
                     for i in groups[group])
        winner = (selector(matrix, ins) if selector else int(np.argmax([
            metric(row[list(ins)]) for row in matrix
        ])))
        if winner is None or type(winner) is not int or not 0 <= winner < len(matrix):
            return None
        scores = np.array([metric(row[list(outs)]) for row in matrix])
        if not np.all(np.isfinite(scores)):
            return None
        rank_from_top = int(np.sum(scores >= scores[winner]))
        percentile = (len(matrix) - rank_from_top + .5) / len(matrix)
        failures += percentile <= .5
        total += 1
    return _decimal(failures / total)


__all__ = [
    "annualized_sharpe",
    "cscv_pbo_from_returns",
    "cscv_design",
    "deflated_sharpe_from_trials",
    "effective_independent_trials",
    "expected_max_sharpe_from_trials",
    "probabilistic_sharpe",
    "probability_of_backtest_overfitting",
]
