"""Safe local exercise of the real-ready pipeline with explicitly invented auth/HTTP."""

import argparse
import asyncio
import json
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import httpx  # noqa: E402
import approved_session as source  # noqa: E402
import one_shot_gate as gate  # noqa: E402
import real_session_worker as worker  # noqa: E402

NOW = datetime(2026, 10, 9, 14, 30, tzinfo=UTC)
AUTH = ("invented-ready-key", "invented-ready-secret", "invented-ready-token")


def loader(*args, **kwargs):
    return AUTH


def token_reader(*args):
    return gate.encode(
        dict(
            access_token=AUTH[2],
            token_type="Bearer",
            expires_at_utc=(NOW + timedelta(hours=1)).isoformat(),
        )
    )


def response(request):
    symbol, market = request.url.params["SYMB"], request.url.params["EXCD"]
    return httpx.Response(
        200,
        json=dict(
            mock_payload=True,
            rt_cd="0",
            output=dict(last="101" if market == source.MARKETS[symbol] else ""),
        ),
    )


def run(out, *, clock=None, transport=None):
    clock = clock or source.FakeClock(NOW)
    started = clock.now()

    def captured_token_reader(*args):
        return gate.encode(
            dict(
                access_token=AUTH[2],
                token_type="Bearer",
                expires_at_utc=(started + timedelta(hours=1)).isoformat(),
            )
        )

    return asyncio.run(
        worker.execute(
            out,
            gate.Permit.mock_permit(clock.now()),
            clock=clock,
            auth_loader=loader,
            token_reader=captured_token_reader,
            transport=transport or httpx.MockTransport(response),
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--wall-clock",
        action="store_true",
        help="actual UTC/monotonic; invented HTTP, about 129 seconds",
    )
    args = parser.parse_args()
    result = run(args.output, clock=source.Clock() if args.wall_clock else None)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result["phase"] == "GRANTED_SESSION_COMPLETE" else 2


if __name__ == "__main__":
    raise SystemExit(main())
