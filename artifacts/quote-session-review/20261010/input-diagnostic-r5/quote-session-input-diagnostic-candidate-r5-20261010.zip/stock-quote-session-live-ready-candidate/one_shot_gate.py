"""Existing-token approval gate. No token issuance, account call or default activation."""

import hashlib
import json
import os
import stat
from datetime import UTC, datetime, timedelta
from pathlib import Path

BASE = Path("/opt/auto-invest")
PROFILE = dict(
    max_attempts=3,
    max_HTTP_per_capture=10,
    max_HTTP=30,
    max_seconds=180,
    capture_spacing=60,
    HTTP_spacing=1,
)
GRANT_KIND = "KIS_EXISTING_TOKEN_ONE_SHOT_V2"
REAL_ORIGIN = "REAL_KIS_HTTP_EXPLICIT_ONE_SHOT"
MOCK_ORIGIN = "MOCK_OF_REAL_KIS_ONE_SHOT"
_SEAL = object()


class Refusal(ValueError):
    pass


def require(value, code):
    if not value:
        raise Refusal(code)


def encode(value):
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
    ).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(result.utcoffset() == timedelta(0), "GRANT_UTC_REQUIRED")
    return result


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "GRANT_DUPLICATE_FIELD")
        result[key] = value
    return result


def runtime_hashes(root):
    selected = [p for p in root.glob("*.py") if not p.name.startswith("test_")]
    selected += list((root / "source/src").rglob("*.py"))
    selected += list((root / "source/src").rglob("*.sql"))
    selected += [
        root / "paper-quote-config.json",
        root / "requirements.lock",
        root
        / "source/specs/177-intraday-paper-challenger/contracts/intraday-preregistration.json",
    ]
    require(
        all(p.is_file() and not p.is_symlink() for p in selected), "RUNTIME_FILE_UNSAFE"
    )
    return {str(p.relative_to(root)): sha(p.read_bytes()) for p in sorted(selected)}


class Permit:
    def __init__(self, data, *, mock, seal):
        require(seal is _SEAL, "ROOT_GRANT_REQUIRED")
        self.data, self.mock, self.sha256 = data, mock, sha(encode(data))
        self.input_kind = MOCK_ORIGIN if mock else REAL_ORIGIN

    def check(self, now):
        require(self.sha256 == sha(encode(self.data)), "ROOT_GRANT_CHANGED")
        require(
            self.data["kind"] == GRANT_KIND
            and encode(self.data["profile"]) == encode(PROFILE),
            "GRANT_SCOPE_MISMATCH",
        )
        require(
            self.data["status"] == "EXPLICITLY_APPROVED_ONCE",
            "EXPLICIT_APPROVAL_REQUIRED",
        )
        began, deadline = (
            utc(self.data["started_at"]),
            utc(self.data["whole_deadline_at"]),
        )
        require(
            deadline == began + timedelta(seconds=300) and began <= now < deadline,
            "GRANT_EXPIRED_OR_CLOCK",
        )

    @classmethod
    def mock_permit(cls, now):
        data = dict(
            kind=GRANT_KIND,
            status="EXPLICITLY_APPROVED_ONCE",
            profile=PROFILE,
            approval_id="a" * 32,
            run_id="b" * 32,
            archive_sha256="0" * 64,
            started_at=now.isoformat(),
            whole_deadline_at=(now + timedelta(seconds=300)).isoformat(),
            runtime_files_sha256={},
            source_kind="INVENTED_TEST_GRANT",
        )
        return cls(data, mock=True, seal=_SEAL)

    @classmethod
    def from_fd(cls, fd, root, *, now=None):
        info = os.fstat(fd)
        require(
            stat.S_ISREG(info.st_mode)
            and info.st_uid == 0
            and stat.S_IMODE(info.st_mode) == 0o600
            and info.st_nlink == 1
            and info.st_size <= 65536,
            "ROOT_PRIVATE_GRANT_REQUIRED",
        )
        data = json.loads(os.pread(fd, 65537, 0), object_pairs_hook=unique)
        fields = {
            "kind",
            "status",
            "profile",
            "approval_id",
            "run_id",
            "archive_sha256",
            "started_at",
            "whole_deadline_at",
            "runtime_files_sha256",
            "source_kind",
        }
        require(
            set(data) == fields and data["source_kind"] == "ROOT_SUPERVISOR_GRANT",
            "ROOT_GRANT_SCHEMA",
        )
        import re

        require(
            all(
                re.fullmatch(r"[a-f0-9]{32}", data[k])
                for k in ("approval_id", "run_id")
            )
            and re.fullmatch(r"[a-f0-9]{64}", data["archive_sha256"]),
            "GRANT_ID_INVALID",
        )
        require(
            data["runtime_files_sha256"] == runtime_hashes(root),
            "RUNTIME_HASH_MISMATCH",
        )
        for relative in data["runtime_files_sha256"]:
            info = (root / relative).stat(follow_symlinks=False)
            require(
                stat.S_ISREG(info.st_mode)
                and info.st_uid == 0
                and not info.st_mode & 0o022,
                "ROOT_RUNTIME_OWNERSHIP_REQUIRED",
            )
        permit = cls(data, mock=False, seal=_SEAL)
        permit.check(now or datetime.now(UTC))
        return permit


def require_integrated_permit(permit, now):
    """Reject subclass/duck and cross-purpose grants before auth or transport."""
    require(type(permit) is Permit, "INTEGRATED_PERMIT_REQUIRED")
    require(type(permit.data) is dict and type(permit.mock) is bool,
            "GRANT_SCOPE_MISMATCH")
    require(permit.data.get("kind") == GRANT_KIND
            and encode(permit.data.get("profile")) == encode(PROFILE)
            and permit.input_kind == (MOCK_ORIGIN if permit.mock else REAL_ORIGIN),
            "GRANT_SCOPE_MISMATCH")
    Permit.check(permit, now)  # Deliberately bypass an instance's overridden check.


DIAGNOSTIC_KIND = "KIS_EXISTING_TOKEN_SINGLE_GET_DIAGNOSTIC_V1"
DIAGNOSTIC_PROFILE = dict(max_attempts=1, max_HTTP_per_capture=1, max_HTTP=1,
                          max_seconds=15, capture_spacing=0, HTTP_spacing=0)
DIAGNOSTIC_REAL_ORIGIN = "REAL_KIS_SINGLE_GET_DIAGNOSTIC"
DIAGNOSTIC_MOCK_ORIGIN = "MOCK_KIS_SINGLE_GET_DIAGNOSTIC"


class DiagnosticPermit(Permit):
    """Distinct purpose and exact budget; the integrated Permit is unchanged."""

    def __init__(self, data, *, mock, seal):
        super().__init__(data, mock=mock, seal=seal)
        self.input_kind = DIAGNOSTIC_MOCK_ORIGIN if mock else DIAGNOSTIC_REAL_ORIGIN

    def check(self, now):
        require(self.sha256 == sha(encode(self.data)), "ROOT_GRANT_CHANGED")
        require(self.data["kind"] == DIAGNOSTIC_KIND
                and encode(self.data["profile"]) == encode(DIAGNOSTIC_PROFILE),
                "DIAGNOSTIC_GRANT_SCOPE_MISMATCH")
        require(self.data["status"] == "EXPLICITLY_APPROVED_ONCE", "EXPLICIT_APPROVAL_REQUIRED")
        began, deadline = utc(self.data["started_at"]), utc(self.data["whole_deadline_at"])
        require(deadline == began + timedelta(seconds=60) and began <= now < deadline,
                "GRANT_EXPIRED_OR_CLOCK")

    @classmethod
    def mock_permit(cls, now):
        data = dict(kind=DIAGNOSTIC_KIND, status="EXPLICITLY_APPROVED_ONCE",
            profile=DIAGNOSTIC_PROFILE.copy(), approval_id="a" * 32, run_id="b" * 32,
            archive_sha256="0" * 64, started_at=now.isoformat(),
            whole_deadline_at=(now + timedelta(seconds=60)).isoformat(),
            runtime_files_sha256={}, source_kind="INVENTED_TEST_GRANT")
        return cls(data, mock=True, seal=_SEAL)


class ExistingAuth:
    """Loads only existing readonly auth after the gate; no account identifier."""

    def __init__(self, credentials, expires, permit):
        require(
            len(credentials) == 3
            and all(isinstance(v, str) and v for v in credentials),
            "AUTH_FIELDS_INVALID",
        )
        self.credentials, self.expires, self.permit = (
            tuple(credentials),
            expires,
            permit,
        )

    @classmethod
    def load(cls, permit, now, *, loader=None, token_reader=None):
        permit.check(now)
        if permit.mock:
            require(
                loader is not None and token_reader is not None,
                "MOCK_AUTH_INJECTION_REQUIRED",
            )
        import kis_quotes as legacy

        loader = loader or legacy.existing_credentials
        token_reader = token_reader or legacy.private_read
        credentials = loader(
            BASE / ".env", BASE / "data/kis_token.json", "production", now=now
        )
        try:
            token = legacy.AccessToken.model_validate_json(
                token_reader(BASE / "data/kis_token.json")
            )
            require(
                token.access_token == credentials[2]
                and token.expires_at_utc.utcoffset() is not None,
                "EXISTING_TOKEN_CHANGED",
            )
            require(
                token.expires_at_utc > now + timedelta(seconds=240),
                "EXISTING_TOKEN_TOO_SHORT_NO_REFRESH",
            )
        except Refusal:
            raise
        except Exception:
            raise Refusal("EXISTING_TOKEN_INVALID_NO_REFRESH") from None
        return cls(credentials, token.expires_at_utc, permit)

    def ready(self, now):
        self.permit.check(now)
        require(
            self.expires > now + timedelta(seconds=60),
            "EXISTING_TOKEN_EXPIRED_NO_REFRESH",
        )
        return True


def real_transport(permit, now):
    permit.check(now)
    require(permit.mock is False, "REAL_TRANSPORT_REQUIRES_ROOT_GRANT")
    import httpx

    return httpx.AsyncHTTPTransport(retries=0, trust_env=False)
