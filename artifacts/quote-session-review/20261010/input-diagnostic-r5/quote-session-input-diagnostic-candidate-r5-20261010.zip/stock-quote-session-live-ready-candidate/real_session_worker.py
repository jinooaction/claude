"""One granted server-local producer+paper consumer. Default auth/network is blocked."""

import argparse
import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import one_shot_gate as gate  # noqa: E402


async def execute(
    out, permit, *, clock=None, auth_loader=None, token_reader=None, transport=None
):
    gate.require_integrated_permit(
        permit, clock.now() if clock else gate.datetime.now(gate.UTC)
    )
    import approved_session as source
    import approved_session_program as paper

    clock = clock or source.Clock()
    auth = gate.ExistingAuth.load(
        permit, clock.now(), loader=auth_loader, token_reader=token_reader
    )
    out.mkdir(mode=0o700, parents=False, exist_ok=False)
    publisher = source.ApprovedPublisher(
        out / "captures", permit=permit, auth=auth, transport=transport, clock=clock
    )
    state = out / "paper"
    error = None
    try:
        for _ in range(3):
            await publisher.collect()
            source.security.diagnostic_stage(publisher.diagnostic, "CAPTURE_BINDING")
            source.require(
                publisher.permit.sha256 == permit.sha256, "ROOT_GRANT_CHANGED"
            )
            source.security.diagnostic_stage(publisher.diagnostic, "PAPER_CONSUMER")
            await paper.step(
                state, publisher.root / "manifest.json", clock, permit=permit
            )
        source.security.diagnostic_stage(publisher.diagnostic, "REPLAY_CHECK")
        duplicate = await paper.step(
            state, publisher.root / "manifest.json", clock, permit=permit
        )
        source.require(
            duplicate["duplicate"] is True, "ROOT_GRANT_RESTART_NOT_IDEMPOTENT"
        )
    except BaseException as exc:
        # Exception payloads may contain provider data or credentials; emit fixed categories.
        error = (
            "GRANT_OR_TOKEN_REJECTED"
            if isinstance(exc, gate.Refusal)
            else "QUOTE_INPUT_REJECTED"
            if isinstance(exc, source.demo.DataError)
            else "GRANTED_SESSION_FAILED"
        )
        if publisher.state != "FAILED":
            publisher.state = "FAILED"
            publisher.pointer()
        publisher.record_rejection(exc)
    finally:
        await publisher.boundary.inner.aclose()
    wallet, bound, commits = paper.summary(state)
    counts = publisher.counters()
    counts["wire_outcome_unknown"] = (
        0 if permit.mock else publisher.boundary.entered - publisher.boundary.completed
    )
    result = dict(
        phase="GRANTED_SESSION_COMPLETE" if error is None else "INPUT_BLOCKED",
        reason=error,
        kind=gate.GRANT_KIND,
        input_kind=permit.input_kind,
        grant_sha256=permit.sha256,
        approval_id=permit.data["approval_id"],
        run_id=permit.data["run_id"],
        clock_kind=(
            "INVENTED_TEST_CLOCK"
            if isinstance(clock, source.FakeClock)
            else "ACTUAL_UTC_AND_MONOTONIC_WITH_MOCK_HTTP"
            if permit.mock
            else "ACTUAL_UTC_AND_MONOTONIC"
        ),
        producer_sha256=source.pin(),
        counters=counts,
        paper=wallet,
        binding=bound,
        session_cursor=len(commits),
        actual_external_GET=counts["actual_external_GET"],
        orders_submitted=0,
        token_issuance_or_refresh=False,
        account_queries=False,
        live_eligible=False,
        strategy_validated=False,
        strategy_trials_added=0,
        legacy_strategy_trial_lower_bound=63,
        source_trade_time_verified=False,
        real_time_verified=False,
        production_readiness=False,
        notice="한정된 기존 토큰 현재가·새 모의원장 검증 / source시간 미확인",
    )
    source.common.immutable(out / "worker-result.json", source.encode(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--grant-fd", type=int)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--audit-only", type=Path)
    args = parser.parse_args()
    execution_started = False
    try:
        if args.audit_only is not None:
            root = args.audit_only
            gate.require(
                root.parent.parent == gate.BASE / "data/quote-session-review"
                and root.name == "worker",
                "AUDIT_SCOPE_DENIED",
            )
            import approved_session_program as paper

            wallet, bound, commits = paper.summary(root / "paper")
            print(
                json.dumps(
                    dict(
                        paper=wallet,
                        binding=bound,
                        session_cursor=len(commits),
                        orders_submitted=0,
                        actual_external_GET=0,
                        auth_reads=0,
                    )
                )
            )
            return 0
        gate.require(
            args.grant_fd is not None and args.output is not None, "ROOT_GRANT_REQUIRED"
        )
        permit = gate.Permit.from_fd(args.grant_fd, ROOT)
        expected = (
            gate.BASE / "data/quote-session-review" / permit.data["run_id"] / "worker"
        )
        gate.require(args.output == expected, "GRANTED_OUTPUT_PATH_REQUIRED")
        execution_started = True
        result = asyncio.run(execute(args.output, permit))
        code = 0 if result["phase"] == "GRANTED_SESSION_COMPLETE" else 2
    except Exception as exc:
        result = dict(
            phase="INPUT_BLOCKED",
            reason=str(exc)
            if isinstance(exc, gate.Refusal)
            and str(exc)
            in {
                "ROOT_GRANT_REQUIRED",
                "AUDIT_SCOPE_DENIED",
                "GRANTED_OUTPUT_PATH_REQUIRED",
                "ROOT_PRIVATE_GRANT_REQUIRED",
                "ROOT_GRANT_SCHEMA",
                "RUNTIME_HASH_MISMATCH",
                "GRANT_EXPIRED_OR_CLOCK",
                "ROOT_GRANT_CHANGED",
                "EXPLICIT_APPROVAL_REQUIRED",
                "NONROOT_APP_IDENTITY_REQUIRED",
                "EXISTING_TOKEN_TOO_SHORT_NO_REFRESH",
                "EXISTING_TOKEN_INVALID_NO_REFRESH",
                "EXISTING_TOKEN_CHANGED",
            }
            else "GRANTED_WORKER_FAILED",
            actual_external_GET=None if execution_started else 0,
            HTTP_wire_outcome="UNKNOWN" if execution_started else "NOT_STARTED",
            orders_submitted=0,
            live_eligible=False,
            token_issuance_or_refresh=False,
        )
        code = 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return code


async def execute_diagnostic(out, permit, *, clock=None, auth_loader=None,
                             token_reader=None, transport=None):
    import approved_session as source

    clock = clock or source.Clock()
    gate.require(type(permit) is gate.DiagnosticPermit, "DIAGNOSTIC_PERMIT_REQUIRED")
    permit.check(clock.now())
    expected = gate.BASE / "data/quote-diagnostic-review" / permit.data["run_id"] / "worker"
    gate.require(permit.mock or out == expected, "GRANTED_OUTPUT_PATH_REQUIRED")
    auth = gate.ExistingAuth.load(permit, clock.now(), loader=auth_loader, token_reader=token_reader)
    out.mkdir(mode=0o700, parents=False, exist_ok=False)
    probe = source.SingleGetDiagnostic(out / "captures", permit=permit, auth=auth,
                                       clock=clock, transport=transport)
    phase, reason = "DIAGNOSTIC_ACCEPTED", "RESPONSE_ACCEPTED"
    try:
        await probe.run()
    except BaseException as exc:
        storage_failed = probe.diagnostic_attempted and not probe.diagnostic_written
        phase = "DIAGNOSTIC_FAILED" if storage_failed or probe.diagnostic["outcome"] == "ACCEPTED" else "DIAGNOSTIC_REJECTED" if isinstance(exc, (gate.Refusal, source.demo.DataError)) else "DIAGNOSTIC_FAILED"
        reason = (
            "DIAGNOSTIC_STORAGE_FAILED" if probe.diagnostic_attempted and not probe.diagnostic_written
            else "TOKEN_OR_GRANT_REJECTED" if isinstance(exc, gate.Refusal)
            else "INPUT_GUARD_REJECTED" if isinstance(exc, source.demo.DataError)
            else "TRANSPORT_OR_RUNTIME_FAILED"
        )
    finally:
        try:
            await probe.inner.aclose()
        except BaseException:
            phase, reason = "DIAGNOSTIC_FAILED", "TRANSPORT_OR_RUNTIME_FAILED"
    result = dict(kind=gate.DIAGNOSTIC_KIND, input_kind=permit.input_kind,
        phase=phase, reason=reason, grant_sha256=permit.sha256,
        approval_id=permit.data["approval_id"], run_id=permit.data["run_id"],
        producer_sha256=source.pin(), counters=dict(HTTP_reserved=probe.reserved,
            HTTP_transport_entered=probe.entered, HTTP_completed=probe.completed,
            wire_outcome_unknown=0 if permit.mock else probe.entered - probe.completed),
        actual_external_GET=0 if permit.mock else probe.completed,
        diagnostic_storage="STORED" if probe.diagnostic_written else "FAILED" if probe.diagnostic_attempted else "NOT_ATTEMPTED",
        orders_submitted=0, token_issuance_or_refresh=False, account_queries=False,
        paper_consumer_used=False, strategy_trials_added=0,
        legacy_strategy_trial_lower_bound=63, source_trade_time_verified=False,
        real_time_verified=False, strategy_validated=False, production_readiness=False)
    source.common.immutable(out / "worker-result.json", source.encode(result))
    return result


def diagnostic_main():
    parser = argparse.ArgumentParser(description="Explicit single GET diagnosis; no paper consumer.")
    parser.add_argument("--diagnose-one-get", action="store_true", required=True)
    parser.add_argument("--grant-fd", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    started = False
    try:
        permit = gate.DiagnosticPermit.from_fd(args.grant_fd, ROOT)
        expected = gate.BASE / "data/quote-diagnostic-review" / permit.data["run_id"] / "worker"
        gate.require(args.output == expected, "GRANTED_OUTPUT_PATH_REQUIRED")
        started = True
        result = asyncio.run(execute_diagnostic(args.output, permit))
        code = 0 if result["phase"] == "DIAGNOSTIC_ACCEPTED" else 2
    except BaseException:
        result = dict(phase="DIAGNOSTIC_BLOCKED", reason="DIAGNOSTIC_WORKER_FAILED",
                      actual_external_GET=None if started else 0, orders_submitted=0,
                      token_issuance_or_refresh=False, account_queries=False,
                      paper_consumer_used=False)
        code = 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(diagnostic_main() if "--diagnose-one-get" in sys.argv[1:] else main())
