"""One local simulated install/backup/byte transfer/paper consume/restore transaction."""

import argparse
import asyncio
import base64
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import demo  # noqa: E402
import kis_session as s  # noqa: E402
import kis_session_program as app  # noqa: E402
from kis_session_cli import supervise  # noqa: E402

RELEASE_FILES = (
    "kis_session.py",
    "kis_session_cli.py",
    "kis_session_program.py",
    "quote_session.py",
    "session_program.py",
    "integration_mock.py",
)


def atomic_bytes(path, raw):
    s.require(not path.is_symlink(), "INTEGRATION_POINTER_SYMLINK")
    temporary = path.parent / ("." + path.name + "." + s.uuid.uuid4().hex)
    try:
        s.common.immutable(temporary, raw)
        temporary.chmod(0o600)
        os.replace(temporary, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        temporary.unlink(missing_ok=True)


async def exercise(root, *, transfer_delay=0, corrupt_sequence=None):
    root.mkdir(mode=0o700, parents=False, exist_ok=False)
    install, backup, incoming = (
        root / "simulated-install",
        root / "backup",
        root / "received",
    )
    for directory in (install, backup, incoming):
        directory.mkdir(mode=0o700)
    prior = s.encode(dict(release="INVENTED_PREVIOUS_RELEASE", simulated=True))
    s.common.immutable(backup / "active-before.json", prior)
    atomic_bytes(install / "active.json", prior)
    bundle = {name: (ROOT / name).read_bytes() for name in RELEASE_FILES}
    release_sha = s.digest(
        s.encode({name: s.digest(raw) for name, raw in bundle.items()})
    )
    release = install / release_sha
    release.mkdir(mode=0o700)
    for name, raw in bundle.items():
        s.common.immutable(release / name, raw)
    atomic_bytes(
        install / "active.json", s.encode(dict(release=release_sha, simulated=True))
    )
    s.common.immutable(
        root / "mock-once-marker.json",
        s.encode(
            dict(approval_kind="INVENTED_MOCK_APPROVAL_ONLY", replay_allowed=False)
        ),
    )
    clock = s.FakeClock(datetime(2026, 10, 9, 14, 30, tzinfo=UTC))
    pub = s.MockPublisher(root / "simulated-server-output", clock=clock)
    paper = root / "paper"
    transfers, total_bytes, restored = [], 0, False
    error = None
    try:
        for sequence in range(1, 4):
            proof = await pub.collect()
            names = [f"capture-{sequence:03d}.json", f"receipt-{sequence:03d}.json"]
            names += [r["response_file"] for r in proof["requests"]]
            envelope = {
                name: dict(
                    content_b64=base64.b64encode(
                        (pub.root / name).read_bytes()
                    ).decode(),
                    sha256=s.digest((pub.root / name).read_bytes()),
                )
                for name in names
            }
            envelope["manifest.json"] = dict(
                content_b64=base64.b64encode(
                    (pub.root / "manifest.json").read_bytes()
                ).decode(),
                sha256=s.digest((pub.root / "manifest.json").read_bytes()),
            )
            wire = s.encode(envelope)
            total_bytes += len(wire)
            s.require(
                len(wire) <= 1048576 and total_bytes <= 3145728,
                "INTEGRATION_TRANSFER_CAP",
            )
            decoded = json.loads(wire)
            if corrupt_sequence == sequence:
                decoded[names[0]]["content_b64"] = base64.b64encode(b"{}").decode()
            # Verify the whole incoming frame before publishing any manifest.
            data = {}
            for name, item in decoded.items():
                s.require(
                    name in names or name == "manifest.json",
                    "INTEGRATION_MEMBER_DENIED",
                )
                raw = base64.b64decode(item["content_b64"], validate=True)
                s.require(s.digest(raw) == item["sha256"], "INTEGRATION_TRANSFER_HASH")
                data[name] = raw
            for name in names:
                s.common.immutable(incoming / name, data[name])
            s.common.publish_manifest(incoming, json.loads(data["manifest.json"]))
            s.require(
                (incoming / "manifest.json").read_bytes() == data["manifest.json"],
                "INTEGRATION_MANIFEST_BYTES",
            )
            await clock.sleep(transfer_delay)
            result = await app.step(paper, incoming / "manifest.json", clock)
            transfers.append(
                dict(
                    sequence=sequence,
                    wire_bytes=len(wire),
                    wire_sha256=s.digest(wire),
                    cursor=result["cursor"],
                    all_original_bytes_match=True,
                )
            )
        duplicate = await app.step(paper, incoming / "manifest.json", clock)
        s.require(duplicate["duplicate"] is True, "INTEGRATION_RESTART_NOT_IDEMPOTENT")
    except Exception as exc:
        error = (
            str(exc) if isinstance(exc, demo.DataError) else "INTEGRATION_MOCK_FAILED"
        )
        if pub.state != "FAILED":
            pub.state = "FAILED"
            pub.pointer()
        s.common.publish_manifest(
            incoming, json.loads((pub.root / "manifest.json").read_bytes())
        )
        atomic_bytes(install / "active.json", prior)
        restored = (install / "active.json").read_bytes() == prior
    wallet, _, commits = app.summary(paper)
    result = dict(
        phase="INTEGRATION_MOCK_COMPLETE" if error is None else "INPUT_BLOCKED",
        reason=error,
        integration_kind="LOCAL_SIMULATED_INSTALL_TRANSFER_CONSUME",
        simulated_install_only=True,
        production_readiness=False,
        release_sha256=release_sha,
        backup_sha256=s.digest(prior),
        restore_attempted=error is not None,
        restore_verified=restored,
        retained_inactive_release_on_failure=True,
        transfers=transfers,
        transferred_bytes=total_bytes,
        counters=pub.counters(),
        paper=wallet,
        session_cursor=len(commits),
        orders_submitted=0,
        live_eligible=False,
        strategy_validated=False,
        strategy_trials_added=0,
        actual_external_GET=0,
        server_operations=0,
        Library_operations=0,
        clock_kind="INVENTED_VIRTUAL_TEST_CLOCK",
    )
    s.common.immutable(root / "integration-receipt.json", s.encode(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not args.child:
        code, result = supervise(
            [
                sys.executable,
                "-I",
                "-B",
                str(Path(__file__).resolve()),
                *sys.argv[1:],
                "--child",
            ],
            seconds=300,
        )
    else:
        try:
            with demo.deny_network():
                result = asyncio.run(exercise(args.root))
            code = 0 if result["phase"] == "INTEGRATION_MOCK_COMPLETE" else 2
        except Exception:
            result = dict(
                phase="INPUT_BLOCKED",
                reason="INTEGRATION_COMMAND_FAILED",
                orders_submitted=0,
                live_eligible=False,
            )
            code = 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
