"""Bounded synthetic publisher, immutable capture pairs and fail-closed reader."""

import asyncio
import hashlib
import json
import os
import re
import tempfile
import time
import uuid
from datetime import UTC, datetime, timedelta
from pathlib import Path

import quote_input_runner as inputs
from quote_handoff import PaperQuoteProvider, make_handoff

PROFILE = dict(
    max_attempts=3, max_GET=12, max_seconds=180, capture_spacing=60, GET_spacing=1
)
CONTRACT = "QUOTE_SESSION_V1_SYNTHETIC_CANDIDATE"
ZERO = "0" * 64


def require(test, code):
    inputs.require(test, code)


def encode(value):
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
    ).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def pin():
    return digest(Path(__file__).read_bytes())


def utc(value):
    parsed = datetime.fromisoformat(value)
    require(parsed.utcoffset() == timedelta(0), "SESSION_UTC_REQUIRED")
    return parsed


def immutable(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o400)
    with os.fdopen(fd, "wb") as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())


def publish_manifest(root, value):
    # Only one pointer changes, after both immutable files have been fsync'd.
    target = root / "manifest.json"
    require(not target.is_symlink(), "SESSION_MANIFEST_SYMLINK")
    fd, name = tempfile.mkstemp(prefix=".manifest-", dir=root)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(encode(value))
            f.flush()
            os.fsync(f.fileno())
        os.replace(name, target)
        directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


class Clock:
    def now(self):
        return datetime.now(UTC)

    def monotonic(self):
        return time.monotonic()

    async def sleep(self, seconds):
        await asyncio.sleep(seconds)


class FakeClock(Clock):
    def __init__(self, now):
        self.current, self.elapsed = now, 0.0

    def now(self):
        return self.current

    def monotonic(self):
        return self.elapsed

    async def sleep(self, seconds):
        self.current += timedelta(seconds=seconds)
        self.elapsed += seconds


class SyntheticPublisher:
    """No token, broker, HTTP client, arbitrary input or live collection command."""

    def __init__(self, root, *, clock=None, session_id=None):
        self.root, self.clock = root, clock or Clock()
        self.id = session_id or uuid.uuid4().hex
        require(re.fullmatch("[a-f0-9]{32}", self.id), "SESSION_ID_INVALID")
        root.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.start, self.mono = self.clock.now(), self.clock.monotonic()
        self.attempts = self.GET = 0
        self.last_start = self.last_completed = None
        self.entries = []
        self._busy = False
        self.state = "ACTIVE"
        self.pointer()

    def remaining(self):
        elapsed = self.clock.monotonic() - self.mono
        require(0 <= elapsed < PROFILE["max_seconds"], "SESSION_DEADLINE_OR_CLOCK")
        require(self.clock.now() >= self.start, "SESSION_CLOCK_REGRESSION")
        return PROFILE["max_seconds"] - elapsed

    def pointer(self):
        publish_manifest(
            self.root,
            dict(
                contract=CONTRACT,
                session_id=self.id,
                started_at=self.start.isoformat(),
                deadline_at=(
                    self.start + timedelta(seconds=PROFILE["max_seconds"])
                ).isoformat(),
                profile=PROFILE,
                input_kind="INVENTED_SYNTHETIC_ONLY",
                producer_sha256=pin(),
                state=self.state,
                published_at=self.clock.now().isoformat(),
                attempts_reserved=self.attempts,
                GET_reserved=self.GET,
                captures=self.entries,
                orders_submitted=0,
            ),
        )

    async def collect(self):
        require(not self._busy, "SESSION_PRODUCER_BUSY")
        self._busy = True
        try:
            return await self._collect()
        finally:
            self._busy = False

    async def _collect(self):
        """One complete attempt. Fail once; a FAILED instance cannot be restarted."""
        require(self.state == "ACTIVE", "SESSION_PRODUCER_TERMINAL")
        try:
            self.remaining()
            require(self.attempts < PROFILE["max_attempts"], "SESSION_ATTEMPT_CAP")
            if self.last_start is not None:
                require(
                    self.clock.monotonic() >= self.last_start,
                    "SESSION_CLOCK_REGRESSION",
                )
                delay = max(0, 60 - (self.clock.monotonic() - self.last_start))
                require(delay < self.remaining(), "SESSION_DEADLINE_OR_CLOCK")
                await self.clock.sleep(delay)
            self.remaining()
            self.attempts += 1
            reserved_at = self.clock.now()
            immutable(
                self.root / f"attempt-{self.attempts:03d}.json",
                encode(
                    dict(
                        attempt=self.attempts,
                        reserved_at=reserved_at.isoformat(),
                        input_kind="INVENTED_SYNTHETIC_ONLY",
                    )
                ),
            )
            self.remaining()
            self.last_start = self.clock.monotonic()
            rows, requests = {}, []
            for symbol in inputs.SYMBOLS:
                require(self.GET < PROFILE["max_GET"], "SESSION_GET_CAP")
                self.GET += 1
                immutable(
                    self.root / f"GET-reserved-{self.GET:03d}.json",
                    encode(
                        dict(reserved=self.GET, symbol=symbol, actual_external_GET=0)
                    ),
                )
                self.remaining()
                if self.last_completed is not None:
                    require(
                        self.clock.monotonic() >= self.last_completed,
                        "SESSION_CLOCK_REGRESSION",
                    )
                    delay = max(0, 1 - (self.clock.monotonic() - self.last_completed))
                    require(delay < self.remaining(), "SESSION_DEADLINE_OR_CLOCK")
                    await self.clock.sleep(delay)
                self.remaining()
                sent = self.clock.now()
                row = await self.synthetic_quote(symbol)
                self.remaining()
                self.last_completed = self.clock.monotonic()
                observed = self.clock.now()
                require(observed >= sent, "SESSION_CLOCK_REGRESSION")
                rows[symbol] = dict(
                    last_USD=row,
                    bid_USD=None,
                    ask_USD=None,
                    exchange="NAS" if symbol == "AAPL" else "AMS",
                    observed_at_utc=observed.isoformat(),
                    source_trade_time=None,
                    source_latency_verified=False,
                    source_response_sha256=digest(
                        encode(dict(INVENTED_ONLY=True, symbol=symbol, value=row))
                    ),
                )
                requests.append(
                    dict(
                        symbol=symbol,
                        sent_at=sent.isoformat(),
                        observed_at=observed.isoformat(),
                    )
                )
            snapshot = make_handoff(
                dict(quotes=rows, quote_request_attempts=4),
                "paper",
                inputs.SYMBOLS,
                emitted_at=self.clock.now(),
            )
            raw = encode(snapshot)
            # Validate exact candidate bytes before storing any immutable price output.
            quotes, report = provider(raw, self.clock.now)
            require(
                report["phase"] == "READY" and len(quotes) == 4,
                "SESSION_PARTIAL_CAPTURE",
            )
            sequence = len(self.entries) + 1
            previous = self.entries[-1]["receipt_sha256"] if self.entries else ZERO
            receipt = dict(
                contract=CONTRACT,
                session_id=self.id,
                sequence=sequence,
                profile=PROFILE,
                producer_sha256=pin(),
                input_kind="INVENTED_SYNTHETIC_ONLY",
                status="SUCCESS",
                snapshot_sha256=digest(raw),
                previous_receipt_sha256=previous,
                attempt_started_at=reserved_at.isoformat(),
                emitted_at=snapshot["emitted_at_utc"],
                requests=requests,
                attempt=self.attempts,
                GET_reserved=self.GET,
                orders_submitted=0,
                actual_external_GET=0,
                token_issuance_or_refresh=False,
            )
            receipt_raw = encode(receipt)
            snapshot_name, receipt_name = (
                f"capture-{sequence:03d}.json",
                f"receipt-{sequence:03d}.json",
            )
            immutable(self.root / snapshot_name, raw)
            immutable(self.root / receipt_name, receipt_raw)
            self.remaining()
            self.entries.append(
                dict(
                    sequence=sequence,
                    snapshot=snapshot_name,
                    receipt=receipt_name,
                    snapshot_sha256=digest(raw),
                    receipt_sha256=digest(receipt_raw),
                )
            )
            if self.attempts == PROFILE["max_attempts"]:
                self.state = "COMPLETED"
            self.pointer()
            return receipt
        except BaseException:
            self.state = "FAILED"
            self.pointer()
            raise

    async def synthetic_quote(self, symbol):
        return str(100 + self.attempts + inputs.SYMBOLS.index(symbol))


def provider(raw, clock):
    for name, approved in inputs.PINS.items():
        require(
            digest((inputs.ROOT / name).read_bytes()) == approved,
            "APPROVED_CONSUMER_CHANGED",
        )
    with tempfile.TemporaryDirectory(prefix="session-verified-price-") as tmp:
        path = Path(tmp) / "quote-handoff.json"
        immutable(path, raw)
        config = json.loads((inputs.ROOT / "paper-quote-config.json").read_bytes())
        return PaperQuoteProvider(path, config, clock=clock).evaluate()


def read_session(path, now):
    require(not path.parent.is_symlink(), "SESSION_ROOT_SYMLINK")
    manifest = json.loads(inputs.read_bytes(path), object_pairs_hook=inputs.unique)
    fields = {
        "contract",
        "session_id",
        "started_at",
        "deadline_at",
        "profile",
        "input_kind",
        "producer_sha256",
        "state",
        "published_at",
        "attempts_reserved",
        "GET_reserved",
        "captures",
        "orders_submitted",
    }
    require(
        set(manifest) == fields
        and manifest["contract"] == CONTRACT
        and manifest["profile"] == PROFILE
        and manifest["producer_sha256"] == pin()
        and manifest["input_kind"] == "INVENTED_SYNTHETIC_ONLY"
        and manifest["orders_submitted"] == 0,
        "SESSION_CONTRACT_INVALID",
    )
    require(
        all(type(v) is int for v in manifest["profile"].values())
        and type(manifest["orders_submitted"]) is int,
        "SESSION_NUMERIC_TYPE_INVALID",
    )
    require(re.fullmatch("[a-f0-9]{32}", manifest["session_id"]), "SESSION_ID_INVALID")
    start, published, deadline = (
        utc(manifest[k]) for k in ("started_at", "published_at", "deadline_at")
    )
    require(
        deadline == start + timedelta(seconds=180) and start <= published < deadline,
        "SESSION_TIME_CONTRACT_INVALID",
    )
    require(
        start <= now < deadline and 0 <= (now - published).total_seconds() <= 120,
        "SESSION_MANIFEST_STALE_OR_FUTURE",
    )
    require(manifest["state"] in ("ACTIVE", "COMPLETED"), "SESSION_TERMINAL_FAILED")
    attempts, GET = manifest["attempts_reserved"], manifest["GET_reserved"]
    require(
        type(attempts) is int
        and type(GET) is int
        and 0 <= attempts <= 3
        and 0 <= GET <= 12
        and GET == 4 * attempts
        and len(manifest["captures"]) == attempts,
        "SESSION_COUNTER_INVALID",
    )
    require(
        manifest["state"] != "COMPLETED" or attempts == 3, "SESSION_COMPLETION_INVALID"
    )
    entries, previous, last_start, last_observed = [], ZERO, None, None
    for index, item in enumerate(manifest["captures"], 1):
        require(
            set(item)
            == {"sequence", "snapshot", "receipt", "snapshot_sha256", "receipt_sha256"}
            and type(item["sequence"]) is int
            and item["sequence"] == index
            and item["snapshot"] == f"capture-{index:03d}.json"
            and item["receipt"] == f"receipt-{index:03d}.json",
            "SESSION_SEQUENCE_OR_PATH_INVALID",
        )
        raw = inputs.read_bytes(path.parent / item["snapshot"])
        receipt_raw = inputs.read_bytes(path.parent / item["receipt"])
        require(
            digest(raw) == item["snapshot_sha256"]
            and digest(receipt_raw) == item["receipt_sha256"],
            "SESSION_PAIR_HASH_MISMATCH",
        )
        proof = json.loads(receipt_raw, object_pairs_hook=inputs.unique)
        require(
            all(
                type(proof.get(k)) is int
                for k in (
                    "sequence",
                    "attempt",
                    "GET_reserved",
                    "orders_submitted",
                    "actual_external_GET",
                )
            ),
            "SESSION_NUMERIC_TYPE_INVALID",
        )
        require(
            set(proof)
            == {
                "contract",
                "session_id",
                "sequence",
                "profile",
                "producer_sha256",
                "input_kind",
                "status",
                "snapshot_sha256",
                "previous_receipt_sha256",
                "attempt_started_at",
                "emitted_at",
                "requests",
                "attempt",
                "GET_reserved",
                "orders_submitted",
                "actual_external_GET",
                "token_issuance_or_refresh",
            }
            and proof["contract"] == CONTRACT
            and proof["session_id"] == manifest["session_id"]
            and proof["sequence"] == proof["attempt"] == index
            and proof["GET_reserved"] == index * 4
            and proof["profile"] == PROFILE
            and proof["producer_sha256"] == pin()
            and proof["input_kind"] == "INVENTED_SYNTHETIC_ONLY"
            and proof["status"] == "SUCCESS"
            and proof["previous_receipt_sha256"] == previous
            and proof["snapshot_sha256"] == digest(raw)
            and proof["orders_submitted"] == proof["actual_external_GET"] == 0
            and proof["token_issuance_or_refresh"] is False,
            "SESSION_RECEIPT_INVALID",
        )
        began, emitted = utc(proof["attempt_started_at"]), utc(proof["emitted_at"])
        require(
            start <= began <= emitted <= published
            and (last_start is None or (began - last_start).total_seconds() >= 60),
            "SESSION_CAPTURE_SPACING_INVALID",
        )
        require(len(proof["requests"]) == 4, "SESSION_REQUEST_COUNT_INVALID")
        for symbol, request in zip(inputs.SYMBOLS, proof["requests"]):
            require(
                set(request) == {"symbol", "sent_at", "observed_at"}
                and request["symbol"] == symbol,
                "SESSION_REQUEST_INVALID",
            )
            sent, observed = utc(request["sent_at"]), utc(request["observed_at"])
            require(
                began <= sent <= observed <= emitted
                and (
                    last_observed is None or (sent - last_observed).total_seconds() >= 1
                ),
                "SESSION_GET_SPACING_INVALID",
            )
            last_observed = observed
        data = json.loads(raw, object_pairs_hook=inputs.unique)
        require(
            data["requested_symbols"] == list(inputs.SYMBOLS)
            and data["unknown"] == {}
            and data["quote_request_attempts"] == 4
            and data["emitted_at_utc"] == proof["emitted_at"]
            and data["source"]["environment"] == "paper",
            "SESSION_SNAPSHOT_INVALID",
        )
        for request in proof["requests"]:
            require(
                data["quotes"][request["symbol"]]["observed_at_utc"]
                == request["observed_at"],
                "SESSION_OBSERVATION_MISMATCH",
            )
        previous, last_start = item["receipt_sha256"], began
        entries.append(dict(item, raw=raw, proof=proof))
    return manifest, entries


def verified_capture(entry, clock):
    quotes, report = provider(entry["raw"], clock)
    require(
        report["phase"] == "READY" and set(quotes) == set(inputs.SYMBOLS),
        "SESSION_PRICE_STALE_OR_PARTIAL",
    )
    data = json.loads(entry["raw"])
    return quotes, dict(
        report,
        output_sha256=entry["snapshot_sha256"],
        emitted_at_utc=data["emitted_at_utc"],
        quote_request_attempts=4,
        prices_USD={s: str(q.last_price_usd) for s, q in quotes.items()},
        session_id=entry["proof"]["session_id"],
        sequence=entry["sequence"],
    )
