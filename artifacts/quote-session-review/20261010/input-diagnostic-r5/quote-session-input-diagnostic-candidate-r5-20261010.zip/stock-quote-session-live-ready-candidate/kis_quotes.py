#!/usr/bin/env python3
"""기존 KIS 토큰으로 해외주식 현재가만 조회. 토큰 발급·주문 기능 없음."""

import argparse
import asyncio
import hashlib
import json
import logging
import os
import signal
import stat
import sys
import time
from datetime import UTC, datetime, timedelta
from io import StringIO
from pathlib import Path

import httpx
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src" if (ROOT / "src").is_dir() else ROOT / "source/src"))

from auto_invest.analytics import intraday_operator as lifecycle  # noqa: E402
from auto_invest.broker.auth import AccessToken  # noqa: E402
from auto_invest.broker.client import (  # noqa: E402
    AsyncTokenBucket, CircuitBreaker, ResilientClient,
)
from auto_invest.broker.overseas import get_quote_resolving_market  # noqa: E402
from auto_invest.market_data.intraday import DataError  # noqa: E402
from quote_handoff import make_handoff, symbols as validate_symbols, write_handoff  # noqa: E402

ENDPOINTS = {
    "production": "https://openapi.koreainvestment.com:9443",
    "paper": "https://openapivts.koreainvestment.com:29443",
}
QUOTE_PATH = "/uapi/overseas-price/v1/quotations/price"
SYMBOLS = ("SPY", "QQQ", "IWM", "TLT", "GLD")
MODE = "KIS_EXISTING_TOKEN_QUOTES_ONLY"
NOTICE = "한국투자 현재가 조회 전용 / 시세 시점·지연 미확정 / 전략 미검증·주문 없음"
_monotonic = time.monotonic
_sleep = asyncio.sleep


def private_read(path):
    """Read an existing private file without modifying or echoing its contents."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > 65536 or info.st_mode & 0o077:
                raise DataError("KIS_EXISTING_AUTH_FILE_NOT_PRIVATE_REGULAR")
            return handle.read(65537).decode("utf-8")
    except DataError:
        raise
    except Exception:
        raise DataError("KIS_EXISTING_AUTH_FILE_UNAVAILABLE") from None


def existing_credentials(env_file, token_cache, environment, *, now=None):
    if environment not in ENDPOINTS:
        raise DataError("KIS_ENVIRONMENT_REQUIRED")
    values = {} if env_file is None else dotenv_values(
        stream=StringIO(private_read(env_file)), interpolate=False,
    )
    # Use the existing process environment or reference file; never persist values.
    key = os.environ.get("KIS_APP_KEY") or values.get("KIS_APP_KEY")
    secret = os.environ.get("KIS_APP_SECRET") or values.get("KIS_APP_SECRET")
    if not key or not secret:
        raise DataError("KIS_EXISTING_APP_CREDENTIALS_UNAVAILABLE")
    configured = os.environ.get("KIS_BASE_URL") or values.get("KIS_BASE_URL")
    if configured and configured.rstrip("/") != ENDPOINTS[environment]:
        raise DataError("KIS_ENVIRONMENT_MISMATCH")
    if token_cache is None:
        raise DataError("KIS_EXISTING_TOKEN_REFERENCE_REQUIRED")
    try:
        token = AccessToken.model_validate_json(private_read(token_cache))
        if not token.access_token or token.token_type.lower() != "bearer":
            raise ValueError
        if token.expires_at_utc.utcoffset() is None:
            raise ValueError
    except DataError:
        raise
    except Exception:
        raise DataError("KIS_EXISTING_TOKEN_INVALID") from None
    if not token.is_valid(now or datetime.now(UTC), margin=timedelta(minutes=1)):
        raise DataError("KIS_CACHED_TOKEN_EXPIRED_NO_REFRESH")
    return key, secret, token.access_token


async def quote_guard(request, *, symbols=None):
    """Final transport boundary: exactly one GET endpoint and public quote fields."""
    allowed = {httpx.URL(u).scheme + "://" + httpx.URL(u).netloc.decode() for u in ENDPOINTS.values()}
    origin = request.url.scheme + "://" + request.url.netloc.decode()
    params = request.url.params
    if (request.method != "GET" or origin not in allowed or request.url.path != QUOTE_PATH
            or request.url.username or request.url.password
            or set(params) != {"AUTH", "EXCD", "SYMB"}
            or params["AUTH"] != "" or params["EXCD"] not in {"NAS", "NYS", "AMS"}
            or params["SYMB"] not in (SYMBOLS if symbols is None else symbols)):
        raise DataError("KIS_QUOTE_ONLY_REQUEST_DENIED")


async def response_guard(response):
    if response.status_code == 200:
        await response.aread()
        try:
            valid = response.json().get("rt_cd") == "0"
        except Exception:
            valid = False
        if not valid:
            raise DataError("KIS_QUOTE_RESPONSE_REJECTED")


async def observe(environment, credentials, *, transport=None, symbols=None, max_requests=None):
    symbols = validate_symbols(SYMBOLS if symbols is None else symbols)
    budget = 3 * len(symbols) if max_requests is None else max_requests
    if type(budget) is not int or not 1 <= budget <= 3 * len(symbols):
        raise DataError("KIS_QUOTE_REQUEST_BUDGET_INVALID")
    key, secret, token = credentials
    quotes, unknown = {}, {}
    receipts = {}
    request_attempts, last_request_at = 0, None

    async def bounded_request(request):
        nonlocal request_attempts, last_request_at
        await quote_guard(request, symbols=symbols)
        if request_attempts >= budget:
            raise DataError("KIS_QUOTE_REQUEST_BUDGET_EXHAUSTED")
        if last_request_at is not None:
            delay = 1 - (_monotonic() - last_request_at)
            if delay > 0:
                await _sleep(delay)
        last_request_at = _monotonic()
        request_attempts += 1

    async def record_response(response):
        await response_guard(response)
        if response.status_code == 200:
            params = response.request.url.params
            receipts[(params["SYMB"], params["EXCD"])] = {
                "observed_at_utc": datetime.now(UTC).isoformat(),
                "source_response_sha256": hashlib.sha256(response.content).hexdigest(),
            }

    async with httpx.AsyncClient(
        base_url=ENDPOINTS[environment], timeout=10, follow_redirects=False,
        trust_env=False, transport=transport,
        event_hooks={"request": [bounded_request], "response": [record_response]},
    ) as http:
        broker = ResilientClient(http, rate_limiter=AsyncTokenBucket(1, 1),
                                 breaker=CircuitBreaker(3, 30), max_retries=1)
        for symbol in symbols:
            try:
                quote = await get_quote_resolving_market(
                    broker, access_token=token, app_key=key, app_secret=secret, symbol=symbol,
                )
                quotes[symbol] = {
                    "last_USD": str(quote.last_price_usd), "bid_USD": str(quote.bid_usd)
                    if quote.bid_usd is not None else None,
                    "ask_USD": str(quote.ask_usd) if quote.ask_usd is not None else None,
                    "exchange": quote.resolved_market,
                    **receipts[(symbol, quote.resolved_market)],
                    "source_trade_time": None, "source_latency_verified": False,
                }
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code in {401, 403}:
                    return dict(status="AUTH_REQUIRED_NO_REFRESH", quotes={},
                                unknown={s: "AUTH_REQUIRED" for s in symbols}, orders_submitted=0,
                                quote_request_attempts=request_attempts)
                unknown[symbol] = "KIS_HTTP_ERROR"
            except Exception:
                unknown[symbol] = "KIS_QUOTE_UNAVAILABLE"
    return dict(status="QUOTES_OBSERVED" if not unknown else "PARTIAL_OR_UNAVAILABLE",
                quotes=quotes, unknown=unknown, orders_submitted=0,
                market_data_response_observed=bool(quotes), quote_request_attempts=request_attempts)


async def start(args):
    # Fail before creating state or touching the network when existing auth is absent.
    existing_credentials(args.env_file, args.token_cache, args.environment)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    async def cycle():
        try:
            credentials = existing_credentials(args.env_file, args.token_cache, args.environment)
        except DataError as exc:
            stop.set()
            result = dict(status="AUTH_REQUIRED_NO_REFRESH", reason=str(exc),
                          quotes={}, orders_submitted=0)
            publish_result(args, result)
            return result
        configured = getattr(args, "symbols", None)
        options = {"symbols": configured} if configured else {}
        if getattr(args, "max_requests", None) is not None:
            options["max_requests"] = args.max_requests
        result = await observe(args.environment, credentials, **options)
        publish_result(args, result)
        if result["status"] == "AUTH_REQUIRED_NO_REFRESH":
            stop.set()
        return result

    try:
        return await lifecycle.run(args.root, cycle=cycle, poll_seconds=60, cycles=args.cycles,
                                   stop_event=stop, mode=MODE + ":" + args.environment)
    finally:
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.remove_signal_handler(sig)


def publish_result(args, result):
    output = getattr(args, "output", None)
    if output is not None:
        write_handoff(output, make_handoff(result, args.environment,
                                           getattr(args, "symbols", None) or SYMBOLS))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("check", "once", "start", "status", "stop"))
    parser.add_argument("--environment", choices=ENDPOINTS)
    parser.add_argument("--env-file", type=Path, help="기존 인증 설정 위치만 참조; 복사·수정 안 함")
    parser.add_argument("--token-cache", type=Path, help="이미 발급된 유효 JSON 토큰 캐시 위치")
    parser.add_argument("--root", type=Path, default=ROOT / "kis-quotes-state")
    parser.add_argument("--cycles", type=int, default=0)
    parser.add_argument("--symbols", type=validate_symbols, default=SYMBOLS,
                        help="명시적 미국 주식·ETF 시세 종목; 전략 승인 종목과 별도")
    parser.add_argument("--output", type=Path,
                        help="승인된 실행에서만 기존 디렉터리의 quote-handoff.json으로 시세 발췌 저장")
    parser.add_argument("--max-requests", type=int, help="전송 직전 검증하는 GET 시도 상한")
    args = parser.parse_args()
    if args.command in {"check", "once", "start"} and args.environment is None:
        parser.error("--environment is required")
    if args.output is not None and (
        args.command not in {"once", "start"} or args.output.name != "quote-handoff.json"
        or args.output.is_symlink() or not args.output.parent.is_dir()
    ):
        parser.error("--output requires once/start and an existing directory with quote-handoff.json")
    logging.disable(logging.CRITICAL)
    try:
        if args.command == "status":
            saved = lifecycle.read(args.root, "status.json") or {}
            result = lifecycle.status(args.root, mode=saved.get("mode", MODE))
        elif args.command == "stop":
            result = lifecycle.request_stop(args.root)
        elif args.command == "start":
            result = asyncio.run(start(args))
        else:
            credentials = existing_credentials(args.env_file, args.token_cache, args.environment)
            result = dict(status="EXISTING_AUTH_READY_NO_NETWORK") if args.command == "check" else (
                asyncio.run(observe(args.environment, credentials, symbols=args.symbols,
                                    max_requests=args.max_requests))
            )
            if args.command == "once":
                publish_result(args, result)
    except DataError as exc:
        result = dict(phase="BLOCKED", reason=str(exc), orders_submitted=0)
        if args.command in {"once", "start"}:
            try:
                publish_result(args, result)
            except (OSError, ValueError):
                result["export_error"] = "QUOTE_EXPORT_FAILED"
    except Exception:
        result = dict(phase="FAILED", reason="KIS_QUOTES_FAILED", orders_submitted=0)
        if args.command in {"once", "start"}:
            try:
                publish_result(args, result)
            except (OSError, ValueError):
                result["export_error"] = "QUOTE_EXPORT_FAILED"
    result = {"notice": NOTICE, **result, "mode": result.get("mode", MODE),
              "quote_endpoint_environment": args.environment or (
                  result.get("mode", "").rsplit(":", 1)[-1]
                  if result.get("mode", "").rsplit(":", 1)[-1] in ENDPOINTS else None),
              "trading_mode": "DISABLED",
              "orders_submitted": 0, "token_issuance_or_refresh": False,
              "account_queries": False, "strategy_uses_quotes": False,
              "synthetic_fallback": False}
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    return 2 if (result.get("phase") in {"BLOCKED", "FAILED", "ALREADY_RUNNING"}
                 or (result.get("last_result") or {}).get("status") == "AUTH_REQUIRED_NO_REFRESH"
                 or result.get("status") in {"AUTH_REQUIRED_NO_REFRESH", "PARTIAL_OR_UNAVAILABLE"}) else 0


if __name__ == "__main__":
    raise SystemExit(main())
