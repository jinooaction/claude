"""KIS request/parser-shaped SESSION candidate. MockTransport only; no auth reads."""

import asyncio
import json
import re
import uuid
from datetime import timedelta
from pathlib import Path
from urllib.parse import unquote

import httpx

import demo
import kis_quotes as legacy
import quote_session as common
from auto_invest.broker import overseas
from quote_handoff import make_handoff

Clock, FakeClock = common.Clock, common.FakeClock
require, digest, encode, utc = common.require, common.digest, common.encode, common.utc
PROFILE = dict(
    max_attempts=3,
    max_HTTP_per_capture=10,
    max_HTTP=30,
    max_seconds=180,
    capture_spacing=60,
    HTTP_spacing=1,
)
CONTRACT = "KIS_QUOTE_SESSION_V1_MOCK_CANDIDATE"
ORIGIN = "MOCK_KIS_HTTP_ONLY"
ENVIRONMENT = "production"
INVENTED_AUTH = (
    "invented-session-key",
    "invented-session-secret",
    "invented-session-token",
)
MARKETS = dict(AAPL="NAS", SCHX="AMS", SPTI="AMS", IAUM="AMS")
PLAN = [
    (s, m)
    for s in common.inputs.SYMBOLS
    for m in (("NAS",) if s == "AAPL" else ("NAS", "NYS", "AMS"))
]


def pin():
    return digest(Path(__file__).read_bytes())


def safe_body(raw):
    require(len(raw) <= 65536, "KIS_SESSION_BODY_LIMIT")
    try:
        data = json.loads(
            raw,
            object_pairs_hook=common.inputs.unique,
            parse_constant=lambda _: require(False, "KIS_SESSION_NONFINITE"),
        )
    except Exception:
        raise demo.DataError("KIS_SESSION_INVALID_JSON") from None

    def walk(value):
        if isinstance(value, dict):
            for key, child in value.items():
                require(
                    not re.search(
                        r"authorization|appkey|appsecret|access.?token|password",
                        key,
                        re.I,
                    ),
                    "KIS_SESSION_SECRET_BODY",
                )
                walk(key)
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
        elif isinstance(value, str):
            for _ in range(3):
                require(
                    not any(secret in value for secret in INVENTED_AUTH)
                    and not re.search(r"bearer\s+", value, re.I),
                    "KIS_SESSION_SECRET_BODY",
                )
                value = unquote(value)

    walk(data)
    require(
        isinstance(data, dict) and data.get("mock_payload") is True,
        "KIS_SESSION_MOCK_PAYLOAD_REQUIRED",
    )
    require(
        data.get("rt_cd") == "0" and isinstance(data.get("output"), dict),
        "KIS_SESSION_BROKER_RESPONSE_FAILED",
    )
    return data


class Boundary(httpx.AsyncBaseTransport):
    """Reserve all HTTP calls, then recheck at the actual mock transport boundary."""

    def __init__(self, publisher, inner, *, dispatch_ready=lambda: True):
        require(
            type(inner) is httpx.MockTransport, "KIS_SESSION_MOCK_TRANSPORT_REQUIRED"
        )
        self.owner, self.inner, self.dispatch_ready = publisher, inner, dispatch_ready
        self.reserved = self.entered = self.completed = 0
        self.local = 0
        self.records = []
        self.last_completed = None
        self.failed = False
        self.busy = False

    async def handle_async_request(self, request):
        require(
            not self.busy and not self.failed, "KIS_SESSION_TRANSPORT_TERMINAL_OR_BUSY"
        )
        self.busy = True
        owner = self.owner
        try:
            owner.remaining()
            require(owner.collecting, "KIS_SESSION_NO_ACTIVE_CAPTURE")
            await legacy.quote_guard(request, symbols=common.inputs.SYMBOLS)
            require(
                str(request.url).startswith(
                    legacy.ENDPOINTS[ENVIRONMENT] + legacy.QUOTE_PATH + "?"
                )
                and len(request.url.params.multi_items()) == 3
                and not request.content,
                "KIS_SESSION_REQUEST_DENIED",
            )
            require(self.local < 10 and self.reserved < 30, "KIS_SESSION_HTTP_CAP")
            symbol, market = PLAN[self.local]
            require(
                (request.url.params["SYMB"], request.url.params["EXCD"])
                == (symbol, market),
                "KIS_SESSION_REQUEST_ROUTE_CHANGED",
            )
            self.reserved += 1
            number = self.reserved
            reserved_at = owner.clock.now()
            common.immutable(
                owner.root / f"http-reserved-{number:03d}.json",
                encode(
                    dict(
                        reservation=number,
                        attempt=owner.attempts,
                        symbol=symbol,
                        market=market,
                        method="GET",
                        endpoint=legacy.QUOTE_PATH,
                        reserved_at=reserved_at.isoformat(),
                        phase="RESERVED_ONLY",
                        actual_external_GET=0,
                    )
                ),
            )
            # Reservation/fsync is not an HTTP execution. Recheck after it and after spacing.
            owner.remaining()
            if self.last_completed is not None:
                require(
                    owner.clock.monotonic() >= self.last_completed,
                    "KIS_SESSION_CLOCK_REGRESSION",
                )
                delay = max(0, 1 - (owner.clock.monotonic() - self.last_completed))
                require(delay < owner.remaining(), "KIS_SESSION_DEADLINE")
                await owner.clock.sleep(delay)
            owner.remaining()
            require(self.dispatch_ready() is True, "KIS_SESSION_DISPATCH_NOT_READY")
            request_budget = min(10, owner.remaining())
            async with asyncio.timeout(request_budget):
                with demo.deny_network():
                    owner.remaining()
                    require(
                        self.dispatch_ready() is True, "KIS_SESSION_DISPATCH_NOT_READY"
                    )
                    sent = owner.clock.now()
                    owner.remaining()
                    delegate = self.inner.handle_async_request
                    # No guard/fsync/await occurs between charging and calling the delegate.
                    self.entered += 1
                    response = await delegate(request)
                    await response.aread()
            self.completed += 1
            observed = owner.clock.now()
            self.last_completed = owner.clock.monotonic()
            require(sent <= observed, "KIS_SESSION_CLOCK_REGRESSION")
            record = dict(
                reservation=number,
                symbol=symbol,
                market=market,
                reserved_at=reserved_at.isoformat(),
                transport_entered_at=sent.isoformat(),
                response_completed_at=observed.isoformat(),
                HTTP_status=response.status_code,
                response_file=f"http-response-{number:03d}.json",
                response_sha256=digest(response.content),
            )
            common.immutable(
                owner.root / f"http-completed-{number:03d}.json", encode(record)
            )
            owner.remaining()
            require(response.status_code == 200, "KIS_SESSION_HTTP_FAILED_NO_RETRY")
            body = safe_body(response.content)
            last = overseas._opt_price(body["output"].get("last"))
            quoted = last is not None and last.is_finite() and last > 0
            require(
                quoted == (market == MARKETS[symbol]),
                "KIS_SESSION_MARKET_OR_QUOTE_UNAVAILABLE",
            )
            record["outcome"] = "QUOTE" if quoted else "EMPTY_MARKET_PROBE"
            common.immutable(owner.root / record["response_file"], response.content)
            self.records.append(record)
            self.local += 1
            return response
        except BaseException:
            self.failed = True
            raise
        finally:
            self.busy = False


class NoRetryClient:
    def __init__(self, http):
        self.http = http

    async def request(self, method, url, **kwargs):
        response = await self.http.request(method, url, **kwargs)
        response.raise_for_status()
        return response


class MockPublisher:
    """Three captures of the existing 10-call route. No live transport factory/CLI."""

    def __init__(
        self,
        root,
        *,
        clock=None,
        session_id=None,
        transport=None,
        dispatch_ready=lambda: True,
    ):
        self.root, self.clock = root, clock or Clock()
        self.id = session_id or uuid.uuid4().hex
        require(re.fullmatch("[a-f0-9]{32}", self.id), "KIS_SESSION_ID_INVALID")
        if transport is not None:
            require(
                type(transport) is httpx.MockTransport,
                "KIS_SESSION_MOCK_TRANSPORT_REQUIRED",
            )
        root.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.start, self.mono = self.clock.now(), self.clock.monotonic()
        self.attempts = 0
        self.last_start = None
        self.entries = []
        self.state, self.collecting = "ACTIVE", False

        def invented(request):
            symbol, market = request.url.params["SYMB"], request.url.params["EXCD"]
            price = (
                str(100 + self.attempts + common.inputs.SYMBOLS.index(symbol))
                if market == MARKETS[symbol]
                else ""
            )
            return httpx.Response(
                200,
                content=encode(
                    dict(
                        mock_payload=True,
                        rt_cd="0",
                        output=dict(last=price, bidp="", askp=""),
                    )
                ),
            )

        self.boundary = Boundary(
            self,
            transport or httpx.MockTransport(invented),
            dispatch_ready=dispatch_ready,
        )
        self.pointer()

    def remaining(self):
        elapsed = self.clock.monotonic() - self.mono
        require(
            0 <= elapsed < 180
            and self.start <= self.clock.now() < self.start + timedelta(seconds=180),
            "KIS_SESSION_DEADLINE_OR_CLOCK",
        )
        return 180 - elapsed

    def pointer(self):
        common.publish_manifest(
            self.root,
            dict(
                contract=CONTRACT,
                session_id=self.id,
                started_at=self.start.isoformat(),
                deadline_at=(self.start + timedelta(seconds=180)).isoformat(),
                profile=PROFILE,
                input_kind=ORIGIN,
                producer_sha256=pin(),
                state=self.state,
                published_at=self.clock.now().isoformat(),
                attempts_reserved=self.attempts,
                HTTP_reserved=self.boundary.reserved,
                HTTP_transport_entered=self.boundary.entered,
                HTTP_completed=self.boundary.completed,
                actual_external_GET=0,
                captures=self.entries,
                orders_submitted=0,
            ),
        )

    def counters(self):
        return dict(
            attempts_reserved=self.attempts,
            HTTP_reserved=self.boundary.reserved,
            HTTP_transport_entered=self.boundary.entered,
            HTTP_completed=self.boundary.completed,
            actual_external_GET=0,
            complete_captures=len(self.entries),
            state=self.state,
            unknown={s: "CAPTURE_ABORTED" for s in MARKETS}
            if self.state == "FAILED"
            else {},
            source_trade_time_verified=False,
            real_time_verified=False,
            token_issuance_or_refresh=False,
            orders_submitted=0,
        )

    async def collect(self):
        require(
            self.state == "ACTIVE" and not self.collecting,
            "KIS_SESSION_PRODUCER_TERMINAL_OR_BUSY",
        )
        self.collecting = True
        try:
            self.remaining()
            require(self.attempts < 3, "KIS_SESSION_ATTEMPT_CAP")
            if self.last_start is not None:
                delay = max(0, 60 - (self.clock.monotonic() - self.last_start))
                require(delay < self.remaining(), "KIS_SESSION_DEADLINE")
                await self.clock.sleep(delay)
            self.remaining()
            self.attempts += 1
            began = self.clock.now()
            common.immutable(
                self.root / f"attempt-{self.attempts:03d}.json",
                encode(
                    dict(
                        attempt=self.attempts,
                        reserved_at=began.isoformat(),
                        phase="ATTEMPT_RESERVED_ONLY",
                    )
                ),
            )
            self.remaining()
            self.last_start, self.boundary.local = self.clock.monotonic(), 0
            offset, rows = len(self.boundary.records), {}
            async with httpx.AsyncClient(
                base_url=legacy.ENDPOINTS[ENVIRONMENT],
                transport=self.boundary,
                timeout=10,
                follow_redirects=False,
                trust_env=False,
            ) as http:
                client = NoRetryClient(http)
                for symbol in common.inputs.SYMBOLS:
                    quote = await overseas.get_quote_resolving_market(
                        client,
                        access_token=INVENTED_AUTH[2],
                        app_key=INVENTED_AUTH[0],
                        app_secret=INVENTED_AUTH[1],
                        symbol=symbol,
                        markets=("NAS",) if symbol == "AAPL" else ("NAS", "NYS", "AMS"),
                    )
                    record = self.boundary.records[-1]
                    require(
                        quote.resolved_market == MARKETS[symbol],
                        "KIS_SESSION_MARKET_CHANGED",
                    )
                    rows[symbol] = dict(
                        last_USD=str(quote.last_price_usd),
                        bid_USD=str(quote.bid_usd)
                        if quote.bid_usd is not None
                        else None,
                        ask_USD=str(quote.ask_usd)
                        if quote.ask_usd is not None
                        else None,
                        exchange=quote.resolved_market,
                        observed_at_utc=record["response_completed_at"],
                        source_response_sha256=record["response_sha256"],
                        source_trade_time=None,
                        source_latency_verified=False,
                    )
            self.remaining()
            records = self.boundary.records[offset:]
            require(len(records) == 10, "KIS_SESSION_CAPTURE_HTTP_COUNT")
            emitted_at = self.clock.now()
            raw = encode(
                make_handoff(
                    dict(quotes=rows, quote_request_attempts=10),
                    ENVIRONMENT,
                    common.inputs.SYMBOLS,
                    emitted_at=emitted_at,
                )
            )
            quotes, report = provider(raw, self.clock.now)
            require(
                report["phase"] == "READY" and len(quotes) == 4,
                "KIS_SESSION_PARTIAL_CAPTURE",
            )
            sequence = len(self.entries) + 1
            proof = dict(
                contract=CONTRACT,
                session_id=self.id,
                sequence=sequence,
                profile=PROFILE,
                producer_sha256=pin(),
                input_kind=ORIGIN,
                status="SUCCESS",
                snapshot_sha256=digest(raw),
                previous_receipt_sha256=self.entries[-1]["receipt_sha256"]
                if self.entries
                else common.ZERO,
                attempt_started_at=began.isoformat(),
                emitted_at=emitted_at.isoformat(),
                requests=records,
                attempt=self.attempts,
                HTTP_reserved=self.boundary.reserved,
                HTTP_transport_entered=self.boundary.entered,
                HTTP_completed=self.boundary.completed,
                actual_external_GET=0,
                orders_submitted=0,
                token_issuance_or_refresh=False,
                source_trade_time_verified=False,
                real_time_verified=False,
            )
            receipt_raw = encode(proof)
            snapshot_name, receipt_name = (
                f"capture-{sequence:03d}.json",
                f"receipt-{sequence:03d}.json",
            )
            common.immutable(self.root / snapshot_name, raw)
            common.immutable(self.root / receipt_name, receipt_raw)
            self.remaining()
            self.entries.append(
                dict(
                    sequence=sequence,
                    snapshot=snapshot_name,
                    receipt=receipt_name,
                    snapshot_sha256=digest(raw),
                    receipt_sha256=digest(receipt_raw),
                )
            )
            if self.attempts == 3:
                self.state = "COMPLETED"
            self.pointer()
            return proof
        except BaseException:
            self.state = "FAILED"
            common.immutable(self.root / "terminal.json", encode(self.counters()))
            self.pointer()
            raise
        finally:
            self.collecting = False


provider = common.provider


def read_session(path, now):
    require(not path.parent.is_symlink(), "KIS_SESSION_ROOT_SYMLINK")
    read = common.inputs.read_bytes

    def loads(raw):
        return json.loads(raw, object_pairs_hook=common.inputs.unique)

    manifest = loads(read(path))
    fields = {
        "contract",
        "session_id",
        "started_at",
        "deadline_at",
        "profile",
        "input_kind",
        "producer_sha256",
        "state",
        "published_at",
        "attempts_reserved",
        "HTTP_reserved",
        "HTTP_transport_entered",
        "HTTP_completed",
        "actual_external_GET",
        "captures",
        "orders_submitted",
    }
    require(
        set(manifest) == fields
        and manifest["contract"] == CONTRACT
        and encode(manifest["profile"]) == encode(PROFILE)
        and manifest["producer_sha256"] == pin()
        and manifest["input_kind"] == ORIGIN,
        "KIS_SESSION_CONTRACT_INVALID",
    )
    require(
        re.fullmatch("[a-f0-9]{32}", manifest["session_id"]), "KIS_SESSION_ID_INVALID"
    )
    for key in (
        "attempts_reserved",
        "HTTP_reserved",
        "HTTP_transport_entered",
        "HTTP_completed",
        "actual_external_GET",
        "orders_submitted",
    ):
        require(type(manifest[key]) is int, "KIS_SESSION_COUNTER_TYPE")
    start, published, deadline = (
        utc(manifest["started_at"]),
        utc(manifest["published_at"]),
        utc(manifest["deadline_at"]),
    )
    require(
        deadline == start + timedelta(seconds=180)
        and start <= published < deadline
        and start <= now < deadline
        and 0 <= (now - published).total_seconds() <= 120,
        "KIS_SESSION_STALE_OR_FUTURE",
    )
    require(manifest["state"] in ("ACTIVE", "COMPLETED"), "KIS_SESSION_PRODUCER_FAILED")
    count = len(manifest["captures"])
    require(
        0 <= count <= 3
        and manifest["attempts_reserved"] == count
        and manifest["HTTP_reserved"]
        == manifest["HTTP_transport_entered"]
        == manifest["HTTP_completed"]
        == count * 10
        and manifest["actual_external_GET"] == manifest["orders_submitted"] == 0
        and (manifest["state"] != "COMPLETED" or count == 3),
        "KIS_SESSION_COUNTER_INVALID",
    )
    entries, previous, last_start, last_observed = [], common.ZERO, None, None
    receipt_fields = {
        "contract",
        "session_id",
        "sequence",
        "profile",
        "producer_sha256",
        "input_kind",
        "status",
        "snapshot_sha256",
        "previous_receipt_sha256",
        "attempt_started_at",
        "emitted_at",
        "requests",
        "attempt",
        "HTTP_reserved",
        "HTTP_transport_entered",
        "HTTP_completed",
        "actual_external_GET",
        "orders_submitted",
        "token_issuance_or_refresh",
        "source_trade_time_verified",
        "real_time_verified",
    }
    request_fields = {
        "reservation",
        "symbol",
        "market",
        "reserved_at",
        "transport_entered_at",
        "response_completed_at",
        "HTTP_status",
        "response_file",
        "response_sha256",
        "outcome",
    }
    for index, item in enumerate(manifest["captures"], 1):
        require(
            set(item)
            == {"sequence", "snapshot", "receipt", "snapshot_sha256", "receipt_sha256"}
            and type(item["sequence"]) is int
            and item["sequence"] == index
            and item["snapshot"] == f"capture-{index:03d}.json"
            and item["receipt"] == f"receipt-{index:03d}.json",
            "KIS_SESSION_SEQUENCE_PATH_INVALID",
        )
        raw, receipt_raw = (
            read(path.parent / item["snapshot"]),
            read(path.parent / item["receipt"]),
        )
        require(
            digest(raw) == item["snapshot_sha256"]
            and digest(receipt_raw) == item["receipt_sha256"],
            "KIS_SESSION_PAIR_HASH",
        )
        proof = loads(receipt_raw)
        require(
            set(proof) == receipt_fields
            and proof["contract"] == CONTRACT
            and proof["session_id"] == manifest["session_id"]
            and encode(proof["profile"]) == encode(PROFILE)
            and proof["producer_sha256"] == pin()
            and proof["input_kind"] == ORIGIN
            and proof["status"] == "SUCCESS"
            and proof["previous_receipt_sha256"] == previous
            and proof["snapshot_sha256"] == digest(raw),
            "KIS_SESSION_RECEIPT_INVALID",
        )
        for key in (
            "sequence",
            "attempt",
            "HTTP_reserved",
            "HTTP_transport_entered",
            "HTTP_completed",
            "actual_external_GET",
            "orders_submitted",
        ):
            require(type(proof[key]) is int, "KIS_SESSION_COUNTER_TYPE")
        require(
            proof["sequence"] == proof["attempt"] == index
            and proof["HTTP_reserved"]
            == proof["HTTP_transport_entered"]
            == proof["HTTP_completed"]
            == index * 10
            and proof["actual_external_GET"] == proof["orders_submitted"] == 0
            and all(
                proof[k] is False
                for k in (
                    "token_issuance_or_refresh",
                    "source_trade_time_verified",
                    "real_time_verified",
                )
            ),
            "KIS_SESSION_RECEIPT_COUNTER_INVALID",
        )
        began, emitted = utc(proof["attempt_started_at"]), utc(proof["emitted_at"])
        require(
            start <= began <= emitted <= published
            and (last_start is None or (began - last_start).total_seconds() >= 60),
            "KIS_SESSION_CAPTURE_SPACING",
        )
        require(len(proof["requests"]) == 10, "KIS_SESSION_HTTP_COUNT")
        selected = {}
        for local, (request, (symbol, market)) in enumerate(
            zip(proof["requests"], PLAN), 1
        ):
            number = (index - 1) * 10 + local
            require(
                set(request) == request_fields
                and type(request["reservation"]) is int
                and request["reservation"] == number
                and request["symbol"] == symbol
                and request["market"] == market
                and type(request["HTTP_status"]) is int
                and request["HTTP_status"] == 200
                and request["response_file"] == f"http-response-{number:03d}.json",
                "KIS_SESSION_HTTP_RECORD_INVALID",
            )
            reserved, sent, observed = (
                utc(request["reserved_at"]),
                utc(request["transport_entered_at"]),
                utc(request["response_completed_at"]),
            )
            require(
                began <= reserved <= sent <= observed <= emitted
                and (
                    last_observed is None or (sent - last_observed).total_seconds() >= 1
                ),
                "KIS_SESSION_HTTP_SPACING",
            )
            response_raw = read(path.parent / request["response_file"])
            require(
                digest(response_raw) == request["response_sha256"],
                "KIS_SESSION_HTTP_RESPONSE_HASH",
            )
            body = safe_body(response_raw)
            last = overseas._opt_price(body["output"].get("last"))
            quoted = last is not None and last.is_finite() and last > 0
            require(
                quoted == (market == MARKETS[symbol])
                and request["outcome"] == ("QUOTE" if quoted else "EMPTY_MARKET_PROBE"),
                "KIS_SESSION_HTTP_RESPONSE_SEMANTICS",
            )
            if quoted:
                selected[symbol] = (request, body["output"])
            last_observed = observed
        data = loads(raw)
        require(
            data["requested_symbols"] == list(common.inputs.SYMBOLS)
            and data["unknown"] == {}
            and data["quote_request_attempts"] == 10
            and data["emitted_at_utc"] == proof["emitted_at"]
            and data["source"]["environment"] == ENVIRONMENT
            and set(data["quotes"]) == set(MARKETS),
            "KIS_SESSION_SNAPSHOT_INVALID",
        )
        for symbol, (request, output) in selected.items():
            row = data["quotes"][symbol]

            def normalized(value):
                price = overseas._opt_price(value)
                return str(price) if price is not None else None

            require(
                row["observed_at_utc"] == request["response_completed_at"]
                and row["exchange"] == MARKETS[symbol]
                and row["source_response_sha256"] == request["response_sha256"]
                and row["last_USD"] == normalized(output.get("last"))
                and row["bid_USD"] == normalized(output.get("bidp"))
                and row["ask_USD"] == normalized(output.get("askp"))
                and row["source_trade_time"] is None
                and row["source_latency_verified"] is False,
                "KIS_SESSION_EXTRACTION_PROVENANCE",
            )
        previous, last_start = item["receipt_sha256"], began
        entries.append(dict(item, raw=raw, proof=proof))
    return manifest, entries


def verified_capture(entry, clock):
    quotes, report = common.verified_capture(entry, clock)
    return quotes, dict(
        report,
        quote_request_attempts=10,
        HTTP_reserved=entry["proof"]["HTTP_reserved"],
        HTTP_transport_entered=entry["proof"]["HTTP_transport_entered"],
        HTTP_completed=entry["proof"]["HTTP_completed"],
        actual_external_GET=0,
    )
