"""Approved capture file -> existing Quote provider; no network or trading signals."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import signal
import stat
import tempfile
from datetime import UTC, datetime
from pathlib import Path

import demo
from quote_handoff import PaperQuoteProvider

ROOT = Path(__file__).resolve().parent
PAPER_ROOT = ROOT / 'state'
MODE = 'APPROVED_CAPTURE_FILE_INPUT_ONLY'
SYMBOLS = ('AAPL', 'SCHX', 'SPTI', 'IAUM')
PINS = {
    'kis_quotes.py': 'e0ea3f45e0e4a8c76c634de3a9f7292422e404d7153a50057e8d8a56b430f12f',
    'quote_handoff.py': 'c4c8b2473e3c5bdccd6df32bd415ecbf2be2cef7210a7b49a7cd8c03967dfb2d',
    'paper-quote-config.json': 'faa70ff94f86fec83cdffd2a23af05c485c7ab7745e3668cfc9e0e195dfe32f2',
}


def require(condition, code):
    if not condition:
        raise demo.DataError(code)


def unique(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'INPUT_DUPLICATE_JSON_FIELD')
        value[key] = item
    return value


def read_bytes(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), 'INPUT_REGULAR_FILE_REQUIRED')
        raw = bytearray()
        while len(raw) <= 16384:
            chunk = os.read(fd, 4096)
            if not chunk:
                break
            raw.extend(chunk)
        require(len(raw) <= 16384, 'INPUT_TOO_LARGE')
        return bytes(raw)
    finally:
        os.close(fd)


def verified_quotes(snapshot, receipt, *, clock=lambda: datetime.now(UTC)):
    """Read once, hash, validate, then evaluate those same bytes with existing provider."""
    try:
        for name, pin in PINS.items():
            require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == pin,
                    'APPROVED_CONSUMER_CHANGED')
        raw = read_bytes(snapshot)
        proof = json.loads(read_bytes(receipt), object_pairs_hook=unique)
        require(isinstance(proof, dict) and proof.get('contract') == 'KIS_QUOTE_HANDOFF_ONCE_V2'
                and proof.get('status') == 'SUCCESS' and proof.get('collector_exit_code') == 0,
                'CAPTURE_RECEIPT_NOT_SUCCESS')
        require(proof.get('output_sha256') == hashlib.sha256(raw).hexdigest(),
                'CAPTURE_OUTPUT_HASH_MISMATCH')
        require(proof.get('installed_files_sha256') == PINS, 'CAPTURE_CODE_PIN_MISMATCH')
        require(proof.get('orders_submitted') == 0
                and proof.get('token_issuance_or_refresh') is False
                and proof.get('maximum_GET_requests') == 12
                and proof.get('maximum_requests_per_second') == 1
                and proof.get('maximum_total_seconds') == 60
                and proof.get('source_trade_time_verified') is False
                and proof.get('real_time_verified') is False,
                'CAPTURE_SAFETY_CONTRACT_INVALID')
        data = json.loads(raw, object_pairs_hook=unique)
        require(data.get('requested_symbols') == list(SYMBOLS)
                and data.get('source', {}).get('environment') == 'production'
                and data.get('unknown') == {} and proof.get('unknown') == {},
                'COMPLETE_APPROVED_CAPTURE_REQUIRED')
        attempts = data.get('quote_request_attempts')
        require(type(attempts) is int and 4 <= attempts <= 12
                and type(proof.get('quote_request_attempts')) is int
                and proof['quote_request_attempts'] == attempts, 'CAPTURE_REQUEST_COUNT_INVALID')
        require(proof.get('quotes') == [dict(symbol=s, currency='USD', **data['quotes'][s])
                                      for s in SYMBOLS], 'CAPTURE_PROJECTION_MISMATCH')
        # The producer's path may change later. Evaluate the exact verified copy,
        # not a second read of that externally supplied path.
        with tempfile.TemporaryDirectory(prefix='verified-quote-input-') as temporary:
            path = Path(temporary) / 'quote-handoff.json'
            path.write_bytes(raw)
            path.chmod(0o400)
            config = json.loads((ROOT / 'paper-quote-config.json').read_bytes())
            quotes, report = PaperQuoteProvider(path, config, clock=clock).evaluate()
        require(report['phase'] == 'READY' and set(quotes) == set(SYMBOLS),
                'CAPTURE_QUOTE_INPUT_BLOCKED')
        return quotes, dict(report, output_sha256=proof['output_sha256'],
                            emitted_at_utc=data['emitted_at_utc'],
                            quote_request_attempts=attempts,
                            prices_USD={s: str(q.last_price_usd) for s, q in quotes.items()},
                            automatic_strategy_input=False, OHLCV_constructed=False)
    except demo.DataError:
        raise
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        raise demo.DataError('CAPTURE_INPUT_UNAVAILABLE_OR_INVALID') from None


def validate_consumption(quotes, report, now):
    """Recheck time against already verified bytes; never re-read the producer path."""
    require(isinstance(now, datetime) and now.utcoffset() is not None, 'PAPER_CLOCK_INVALID')
    emitted = datetime.fromisoformat(report['emitted_at_utc'])
    require(0 <= (now - emitted).total_seconds() <= 120, 'CAPTURE_EMISSION_STALE_OR_FUTURE')
    for symbol, quote in quotes.items():
        require(0 <= (now - quote.quoted_at_utc).total_seconds() <= 120,
                'CAPTURE_RESPONSE_STALE_OR_FUTURE')
        trade = report['quote_details'][symbol]['source_trade_time']
        if trade is not None:
            require(0 <= (now - datetime.fromisoformat(trade)).total_seconds() <= 120,
                    'CAPTURE_TRADE_STALE_OR_FUTURE')


def status(root, *, clock=lambda: datetime.now(UTC)):
    saved = demo.lifecycle.read(root, 'status.json') if root.exists() else None
    require(saved is None or saved.get('mode') == MODE, 'FOREIGN_OPERATOR_STATE')
    state = demo.lifecycle.status(root, mode=MODE)
    binding = demo.lifecycle.read(root, 'input.json') if root.exists() else None
    try:
        require(binding is not None, 'CAPTURE_INPUT_NOT_BOUND')
        _, report = verified_quotes(Path(binding['snapshot']), Path(binding['receipt']), clock=clock)
    except demo.DataError as error:
        report = dict(phase='BLOCKED', reason=str(error), prices_USD={}, accepted_symbols=[])
    # Never display the old last_result prices as current after any input failure.
    state.pop('last_result', None)
    if state.get('last_error') and not state.get('running'):
        state['phase'] = 'INPUT_BLOCKED'
    return dict(state, quote_input=report,
                synthetic_paper_ledger=demo.paper_status(PAPER_ROOT),
                strategy_uses_quotes=False, market_connection_verified=False,
                real_time_verified=False, live_eligible=False, broker_orders_enabled=False)


async def start(root, snapshot, receipt, *, cycles=0, clock=lambda: datetime.now(UTC)):
    saved = demo.lifecycle.read(root, 'status.json') if root.exists() else None
    require(saved is None or saved.get('mode') == MODE, 'FOREIGN_OPERATOR_STATE')
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    async def cycle():
        try:
            _, report = verified_quotes(snapshot, receipt, clock=clock)
            binding = dict(snapshot=str(snapshot.absolute()), receipt=str(receipt.absolute()))
            prior = demo.lifecycle.read(root, 'input.json')
            require(prior is None or prior == binding, 'INPUT_BINDING_CHANGED_USE_SEPARATE_ROOT')
            if prior is None:
                demo.lifecycle.publish(root, 'input.json', binding)
        except demo.DataError:
            stop.set()  # Fail once, stop only this new input worker, no retry/old price fallback.
            raise
        return dict(report, orders_submitted=0)

    try:
        result = await demo.lifecycle.run(root, cycle=cycle, cycles=cycles, poll_seconds=60,
                                          stop_event=stop, mode=MODE)
        if result['phase'] == 'ALREADY_RUNNING':
            return result
        return status(root, clock=clock)
    finally:
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.remove_signal_handler(sig)


def stop(root):
    saved = demo.lifecycle.read(root, 'status.json') if root.exists() else None
    require(saved is None or saved.get('mode') == MODE, 'FOREIGN_OPERATOR_STATE')
    return dict(demo.lifecycle.request_stop(root), mode=MODE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('start', 'status', 'stop'))
    parser.add_argument('--root', type=Path, default=ROOT / 'quote-state')
    parser.add_argument('--snapshot', type=Path)
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--cycles', type=int, default=0)
    args = parser.parse_args()
    try:
        with demo.deny_network():
            if args.command == 'start':
                require(args.snapshot is not None and args.receipt is not None,
                        'CAPTURE_SNAPSHOT_AND_RECEIPT_REQUIRED')
                result = asyncio.run(start(args.root, args.snapshot, args.receipt, cycles=args.cycles))
            elif args.command == 'stop':
                result = stop(args.root)
            else:
                result = status(args.root)
    except demo.DataError as error:
        result = dict(phase='INPUT_BLOCKED', reason=str(error))
    except Exception:
        result = dict(phase='INPUT_BLOCKED', reason='QUOTE_INPUT_RUNNER_FAILED')
    result.update(orders_submitted=0, notice='가격 응답 파일 수신 / 자동매매 전략과 실시간 연결은 미검증')
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    return 2 if result.get('phase') in {'INPUT_BLOCKED', 'FAILED', 'ALREADY_RUNNING'} else 0


if __name__ == '__main__':
    raise SystemExit(main())
