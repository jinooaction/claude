#!/usr/bin/env python3
"""Bounded local SESSION commands; parent kills only its newly spawned child group."""

import argparse
import json
import os
import signal
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def supervise(command, seconds=180):
    process = subprocess.Popen(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        env={"PATH": "/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1"},
    )
    try:
        raw, _ = process.communicate(timeout=seconds)
        if len(raw) > 65536:
            raise ValueError("SESSION_OUTPUT_LIMIT")
        result = json.loads(raw)
        if (
            result.get("orders_submitted") != 0
            or result.get("live_eligible") is not False
        ):
            raise ValueError("SESSION_RESULT_INVALID")
        return process.returncode, result
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
        return 2, dict(
            phase="BOUNDED_END",
            reason="NEW_CHILD_GROUP_HARD_TIMEOUT",
            orders_submitted=0,
            live_eligible=False,
        )
    except Exception:
        return 2, dict(
            phase="INPUT_BLOCKED",
            reason="SESSION_CHILD_RESULT_INVALID",
            orders_submitted=0,
            live_eligible=False,
        )
    except BaseException:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
        return 2, dict(
            phase="BOUNDED_END",
            reason="PARENT_INTERRUPTED_NEW_GROUP_STOPPED",
            orders_submitted=0,
            live_eligible=False,
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("start", "status", "stop", "mock", "feed-mock")
    )
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not args.child:
        code, result = supervise(
            [
                sys.executable,
                "-I",
                "-B",
                str(Path(__file__).resolve()),
                *sys.argv[1:],
                "--child",
            ],
            180 if args.command in ("start", "mock", "feed-mock") else 10,
        )
    else:
        import asyncio
        from datetime import UTC, datetime
        import demo
        import kis_session as session
        import kis_session_program as program

        try:
            with demo.deny_network():
                if args.command == "mock":
                    args.root.mkdir(mode=0o700, parents=False, exist_ok=False)
                    clock = session.FakeClock(datetime(2026, 10, 9, 14, 30, tzinfo=UTC))
                    publisher = session.MockPublisher(
                        args.root / "captures", clock=clock
                    )
                    state_root = args.root / "paper"
                    outcomes = []

                    async def run():
                        for _ in range(3):
                            await publisher.collect()
                            outcomes.append(
                                await program.step(
                                    state_root, publisher.root / "manifest.json", clock
                                )
                            )

                    asyncio.run(run())
                    result = program.status(
                        state_root, publisher.root / "manifest.json", clock=clock
                    )
                    result.update(
                        phase="MOCK_COMPLETE",
                        session_cursor=outcomes[-1]["cursor"],
                        actual_external_GET=0,
                        HTTP_transport_entered=publisher.boundary.entered,
                        HTTP_completed=publisher.boundary.completed,
                        HTTP_reserved=publisher.boundary.reserved,
                        profile=session.PROFILE,
                        clock_kind="INVENTED_VIRTUAL_TEST_CLOCK",
                        production_readiness=False,
                    )
                elif args.command == "feed-mock":
                    publisher = session.MockPublisher(args.root)

                    async def feed():
                        async with asyncio.timeout(175):
                            for _ in range(3):
                                await publisher.collect()

                    asyncio.run(feed())
                    result = dict(
                        phase="MOCK_FEED_COMPLETE",
                        input_kind="MOCK_KIS_HTTP_ONLY",
                        actual_external_GET=0,
                        HTTP_transport_entered=publisher.boundary.entered,
                        HTTP_completed=publisher.boundary.completed,
                        HTTP_reserved=publisher.boundary.reserved,
                        profile=session.PROFILE,
                    )
                elif args.command == "start":
                    session.require(
                        args.manifest is not None, "SESSION_MANIFEST_REQUIRED"
                    )
                    result = asyncio.run(program.start(args.root, args.manifest))
                elif args.command == "status":
                    result = program.status(args.root, args.manifest)
                else:
                    result = program.stop(args.root)
        except Exception as error:
            result = dict(
                phase="INPUT_BLOCKED",
                reason=str(error)
                if isinstance(error, demo.DataError)
                else "SESSION_COMMAND_FAILED",
            )
            if "publisher" in locals():
                result.update(publisher.counters())
        result.update(
            orders_submitted=0,
            live_eligible=False,
            strategy_validated=False,
            strategy_trials_added=0,
        )
        code = (
            2
            if result.get("phase")
            in ("INPUT_BLOCKED", "BOUNDED_END", "ALREADY_RUNNING")
            else 0
        )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
