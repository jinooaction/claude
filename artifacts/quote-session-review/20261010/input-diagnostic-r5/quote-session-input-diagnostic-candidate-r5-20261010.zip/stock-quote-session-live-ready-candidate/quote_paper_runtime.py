"""Four-quote plumbing policy using the existing paper router, never an alpha claim."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import tempfile
from datetime import UTC, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import demo
import quote_input_runner as inputs
from dateutil.relativedelta import relativedelta

from auto_invest.config.caps import SizingCaps
from auto_invest.config.enums import OrderType, Side, StrategyStage
from auto_invest.config.rules import Action, PriceTrigger, TradingRule
from auto_invest.config.whitelist import Whitelist
from auto_invest.execution.order_router import OrderRouter, _choose_paper_fill_price
from auto_invest.market_data.intraday import CALENDAR, NY
from auto_invest.paper.virtual_positions import recompute_virtual_positions
from auto_invest.persistence import db

SYMBOLS = ('AAPL', 'SCHX', 'SPTI', 'IAUM')
POLICY = 'quote-basket-plumbing-v1'
INITIAL = Decimal('100000')
FRACTION = Decimal('.05')
COMMISSION = Decimal('.0025')
ZERO = '0' * 64
ACCOUNT = 'LOCAL_QUOTE_PAPER'
PREVIOUS_DELIVERED_IMPLEMENTATION = 'c4f72462f374d784a964d7098ec1ab8e5c8fd338e33208f968a8143a4e07a919'


def require(condition, code):
    if not condition:
        raise demo.DataError(code)


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def contract():
    return dict(policy_id=POLICY, purpose='EXECUTION_PLUMBING_ONLY_UNVALIDATED',
                symbols=list(SYMBOLS), virtual_initial_cash_USD=str(INITIAL),
                one_time_allocation_per_symbol=str(FRACTION), commission_per_side=str(COMMISSION),
                cap_percent=[5, 20, 80], month_basis='NEW_YORK_CALENDAR_MONTH_CLAMP_DAY',
                exit_margin_minutes=15, session='XNYS_REGULAR_ONLY',
                implementation_sha256=sha(Path(__file__).read_bytes()))


def regular_session(now):
    require(isinstance(now, datetime) and now.utcoffset() is not None, 'PAPER_CLOCK_INVALID')
    day = now.astimezone(NY).date().isoformat()
    if not CALENDAR.is_session(day):
        return dict(regular_open=False, date_NY=day, reason='NON_SESSION')
    opening = CALENDAR.session_open(day).to_pydatetime()
    closing = CALENDAR.session_close(day).to_pydatetime()
    return dict(regular_open=opening <= now < closing, date_NY=day,
                open_utc=opening.isoformat(), close_utc=closing.isoformat(),
                entry_allowed=opening <= now < closing - timedelta(minutes=15))


def holding_deadlines(entry):
    deadline = (entry.astimezone(NY) + relativedelta(months=1)).astimezone(UTC)
    day = deadline.astimezone(NY).date().isoformat()
    last = CALENDAR.date_to_session(day, direction='previous')
    if CALENDAR.session_close(last).to_pydatetime() > deadline:
        last = CALENDAR.previous_session(last)
    planned = CALENDAR.session_close(last).to_pydatetime() - timedelta(minutes=15)
    require(entry < planned < deadline, 'PAPER_HOLDING_WINDOW_INVALID')
    return deadline.isoformat(), planned.isoformat()


class NoBroker:
    async def request(self, *args, **kwargs):
        raise demo.DataError('PAPER_BROKER_CALL_FORBIDDEN')

    get = post = request


def _positions(rows):
    return {s: p.qty for s, p in rows.items() if p.qty}


def initial_wallet():
    return dict(cash_USD=str(INITIAL), positions={}, simulated_fills=0,
                commissions_USD='0', processed_captures=0, holding_deadlines={},
                policy_id=POLICY, strategy_validated=False, orders_submitted=0)


def ledger_contract(conn):
    """Only this implementation and the exact previously delivered contract resume."""
    metadata = conn.execute('SELECT payload FROM quote_paper_contract').fetchall()
    current = contract()
    previous = dict(current, implementation_sha256=PREVIOUS_DELIVERED_IMPLEMENTATION)
    require(len(metadata) == 1 and json.loads(metadata[0][0]) in (current, previous),
            'PAPER_CONTRACT_CHANGED')
    return json.loads(metadata[0][0])


def replay(conn):
    """Reconcile the append-only cycle chain against the existing paper audit view."""
    saved_contract = ledger_contract(conn)
    cash, fees, previous, count, fill_count = INITIAL, Decimal('0'), ZERO, 0, 0
    deadlines, ever_bought, correlations = {}, set(), set()
    last_clock = None
    for row in conn.execute('SELECT * FROM quote_paper_cycles ORDER BY id'):
        raw = row['payload'].encode()
        require(row['previous_sha256'] == previous and row['event_sha256'] == sha(raw),
                'PAPER_EVENT_CHAIN_INVALID')
        event = json.loads(raw)
        require(event['previous_sha256'] == previous and event['capture_sha256'] == row['capture_sha256']
                and event['contract_sha256'] == sha(encode(saved_contract))
                and Decimal(event['cash_before_USD']) == cash, 'PAPER_EVENT_INVALID')
        previous, count = row['event_sha256'], count + 1
        last_clock = event.get('commit_checked_at_utc', event['decision_at_utc'])
        for fill in event['fills']:
            correlation = fill['correlation_id']
            require(correlation not in correlations, 'PAPER_DUPLICATE_FILL')
            correlations.add(correlation)
            audit_rows = conn.execute("SELECT payload_json FROM audit_log WHERE correlation_id=? "
                                      "AND event_type='ORDER_PAPER_FILLED'", (correlation,)).fetchall()
            require(len(audit_rows) == 1 and json.loads(audit_rows[0][0]) == fill['audit_payload'],
                    'PAPER_AUDIT_RECONCILIATION_FAILED')
            value = fill['audit_payload']
            qty, price = value['qty'], Decimal(value['simulated_fill_price_usd'])
            require(type(qty) is int and qty > 0 and price.is_finite() and price > 0
                    and value['symbol'] in SYMBOLS and value['side'] in {'BUY', 'SELL'},
                    'PAPER_FILL_INVALID')
            fee = (qty * price * COMMISSION).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
            require(Decimal(fill['commission_USD']) == fee, 'PAPER_FEE_INVALID')
            cash += (-qty * price if value['side'] == 'BUY' else qty * price) - fee
            fees, fill_count = fees + fee, fill_count + 1
            require(cash >= 0, 'PAPER_CASH_RECONCILIATION_FAILED')
            if value['side'] == 'BUY':
                require(value['symbol'] not in ever_bought, 'PAPER_REENTRY_FORBIDDEN')
                ever_bought.add(value['symbol'])
                expected = holding_deadlines(datetime.fromisoformat(
                    fill.get('completed_at_utc', event['decision_at_utc'])))
                require(fill['deadline_utc'] == expected[0] and fill['planned_exit_utc'] == expected[1],
                        'PAPER_HOLDING_DEADLINE_INVALID')
                deadlines[value['symbol']] = dict(deadline_utc=expected[0], planned_exit_utc=expected[1])
        require(Decimal(event['cash_after_USD']) == cash, 'PAPER_CASH_RECONCILIATION_FAILED')
    audit_count = conn.execute("SELECT COUNT(*) FROM audit_log WHERE event_type='ORDER_PAPER_FILLED'").fetchone()[0]
    require(audit_count == fill_count, 'PAPER_ORPHAN_AUDIT_FILL')
    virtual = recompute_virtual_positions(conn, paper_session_id=1)
    require(all(s in SYMBOLS and p.qty >= 0 for s, p in virtual.items()), 'PAPER_POSITION_INVALID')
    wallet = dict(initial_wallet(), cash_USD=str(cash), positions=_positions(virtual),
                  simulated_fills=fill_count, commissions_USD=str(fees), processed_captures=count,
                  holding_deadlines={s: v for s, v in deadlines.items() if virtual[s].qty},
                  ever_bought=sorted(ever_bought), last_decision_at_utc=last_clock,
                  last_event_sha256=previous, reconciliation='MATCHED_EXISTING_PAPER_AUDIT')
    return wallet


def _read_wallet_unlocked(path):
    if not path.exists():
        require(not path.is_symlink(), 'PAPER_DB_SYMLINK')
        return initial_wallet()
    require(not path.is_symlink() and path.is_file(), 'PAPER_DB_INVALID')
    conn = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute('PRAGMA query_only=ON')
        conn.execute('BEGIN')  # One snapshot across the cycle chain and audit reconciliation.
        return replay(conn)
    except sqlite3.Error:
        raise demo.DataError('PAPER_LEDGER_UNAVAILABLE_OR_INVALID') from None
    finally:
        conn.close()


def read_wallet(path):
    if not path.parent.exists():
        return _read_wallet_unlocked(path)
    with demo.lifecycle.lock(path.parent, 'quote-ledger.lock', blocking=True):
        return _read_wallet_unlocked(path)


def holding_status(wallet, now):
    due = [s for s, v in wallet['holding_deadlines'].items()
           if now >= datetime.fromisoformat(v['planned_exit_utc'])]
    overdue = [s for s, v in wallet['holding_deadlines'].items()
               if now >= datetime.fromisoformat(v['deadline_utc'])]
    return dict(exit_due_symbols=due, overdue_symbols=overdue,
                phase='OVERDUE_NEEDS_ATTENTION' if overdue else 'EXIT_DUE' if due else 'WITHIN_WINDOW',
                maximum_holding_guaranteed_in_actual_operation=False)


class QuotePaperRuntime:
    def __init__(self, root):
        # A status reader waits until schema, policy metadata and migrations are complete.
        with demo.lifecycle.lock(root, 'quote-ledger.lock', blocking=True):
            self._open(root)

    def _open(self, root):
        demo.lifecycle.prepare_root(root)
        self.path = root / 'quote-paper.db'
        require(not self.path.is_symlink(), 'PAPER_DB_SYMLINK')
        if self.path.exists():
            _read_wallet_unlocked(self.path)  # Refuse foreign/incomplete files before writable access.
        else:
            self._initialize(root)
        self.conn = db.get_connection(self.path)
        self.conn.execute('PRAGMA synchronous=FULL')
        self.router = OrderRouter(
            conn=self.conn, broker=NoBroker(), access_token='', app_key='', app_secret='',
            account_no=ACCOUNT, paper_mode=True, paper_session_id=1,
            whitelist=Whitelist(symbols=SYMBOLS, accounts={ACCOUNT}, order_types={OrderType.LIMIT}),
            caps=SizingCaps(per_trade_pct=5, per_symbol_pct=20, global_exposure_pct=80,
                            canary_capital_pct=5, canary_min_duration_days=10,
                            canary_acceptance_drawdown_pct=3), halt_path=root / 'local-paper-halt.flag')

    def _initialize(self, root):
        # Only a complete, checkpointed database is linked to the final name.
        # A crash can leave an unpublished temporary file, never a broken final ledger.
        fd, temporary_name = tempfile.mkstemp(prefix='.quote-paper-init-', suffix='.db', dir=root)
        os.close(fd)
        temporary, conn = Path(temporary_name), None
        try:
            conn = db.get_connection(temporary)
            conn.execute('PRAGMA synchronous=FULL')
            db.migrate(conn)
            conn.executescript('''
                CREATE TABLE quote_paper_contract(payload TEXT NOT NULL);
                CREATE TABLE quote_paper_cycles(id INTEGER PRIMARY KEY, capture_sha256 TEXT UNIQUE NOT NULL,
                    previous_sha256 TEXT NOT NULL, event_sha256 TEXT NOT NULL, payload TEXT NOT NULL);
                CREATE TRIGGER qp_contract_no_update BEFORE UPDATE ON quote_paper_contract
                    BEGIN SELECT RAISE(ABORT, 'append-only'); END;
                CREATE TRIGGER qp_contract_no_delete BEFORE DELETE ON quote_paper_contract
                    BEGIN SELECT RAISE(ABORT, 'append-only'); END;
                CREATE TRIGGER qp_cycle_no_update BEFORE UPDATE ON quote_paper_cycles
                    BEGIN SELECT RAISE(ABORT, 'append-only'); END;
                CREATE TRIGGER qp_cycle_no_delete BEFORE DELETE ON quote_paper_cycles
                    BEGIN SELECT RAISE(ABORT, 'append-only'); END;
            ''')
            conn.execute('INSERT INTO quote_paper_contract(payload) VALUES(?)', (encode(contract()).decode(),))
            replay(conn)
            require(conn.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0] == 0,
                    'PAPER_INITIAL_CHECKPOINT_FAILED')
            require(conn.execute('PRAGMA journal_mode=DELETE').fetchone()[0] == 'delete',
                    'PAPER_INITIAL_CHECKPOINT_FAILED')
            conn.close()
            conn = None
            with temporary.open('rb') as handle:
                os.fsync(handle.fileno())
            os.link(temporary, self.path)  # Atomic and non-replacing, even against a new competing file.
            directory_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            if conn is not None:
                conn.close()
            # Cleanup is restricted to this invocation's private, unpublished initializer.
            for path in (temporary, Path(str(temporary) + '-wal'), Path(str(temporary) + '-shm')):
                path.unlink(missing_ok=True)

    def close(self):
        self.conn.close()

    async def process(self, quotes, report, *, clock=lambda: datetime.now(UTC)):
        require(self.router.paper_mode is True and isinstance(self.router.broker, NoBroker),
                'PAPER_ROUTER_REQUIRED')
        require(set(quotes) == set(SYMBOLS), 'PAPER_COMPLETE_QUOTE_REQUIRED')
        capture = report['output_sha256']
        require(len(capture) == 64 and all(c in '0123456789abcdef' for c in capture), 'PAPER_CAPTURE_HASH_INVALID')
        self.conn.execute('BEGIN IMMEDIATE')
        try:
            now = clock()  # After initialization and any SQLite write-lock wait.
            inputs.validate_consumption(quotes, report, now)
            session = regular_session(now)
            wallet = replay(self.conn)
            if self.conn.execute('SELECT 1 FROM quote_paper_cycles WHERE capture_sha256=?', (capture,)).fetchone():
                self.conn.execute('COMMIT')
                return dict(wallet, duplicate_capture=True, decision='ALREADY_PROCESSED', session=session)
            require(not wallet.get('last_decision_at_utc') or now >= datetime.fromisoformat(wallet['last_decision_at_utc']),
                    'PAPER_CLOCK_REGRESSION')
            cash = Decimal(wallet['cash_USD'])
            owned = dict(wallet['positions'])
            nav = cash + sum(owned.get(s, 0) * q.last_price_usd for s, q in quotes.items())
            require(nav.is_finite() and nav > 0, 'PAPER_NAV_INVALID')
            provenance = {s: dict(report['quote_details'][s], response_observed_at_utc=q.quoted_at_utc.isoformat())
                          for s, q in quotes.items()}
            event = dict(contract_sha256=sha(encode(ledger_contract(self.conn))), capture_sha256=capture,
                         consumer_implementation_sha256=contract()['implementation_sha256'],
                         previous_sha256=wallet.get('last_event_sha256', ZERO), decision_at_utc=now.isoformat(),
                         cash_before_USD=str(cash), session=session, quote_provenance=provenance,
                         quote_prices_USD={s: str(q.last_price_usd) for s, q in quotes.items()},
                         quote_request_attempts=report['quote_request_attempts'],
                         decisions=[], fills=[], strategy_validated=False,
                         fill_assumption='SNAPSHOT_ONLY_NO_LIQUIDITY_OR_TRADE_FRESHNESS_PROOF')
            in_session = session['regular_open'] and all(
                datetime.fromisoformat(session['open_utc']) <= q.quoted_at_utc <= now
                and (now - q.quoted_at_utc).total_seconds() <= 120 for q in quotes.values())
            for symbol in SYMBOLS:
                qty = owned.get(symbol, 0)
                due = qty and now >= datetime.fromisoformat(wallet['holding_deadlines'][symbol]['planned_exit_utc'])
                side = Side.SELL if due else Side.BUY
                decision = 'HOLD'
                if not in_session:
                    decision = 'WAIT_REGULAR_QUOTE' if session['regular_open'] else 'MARKET_CLOSED'
                elif due:
                    decision = 'EXIT_CALENDAR_MONTH'
                elif not qty and symbol not in wallet.get('ever_bought', []) and session.get('entry_allowed'):
                    decision = 'ENTER_FIXED_PLUMBING_ALLOCATION'
                event['decisions'].append(dict(symbol=symbol, action=decision))
                if decision not in {'EXIT_CALENDAR_MONTH', 'ENTER_FIXED_PLUMBING_ALLOCATION'}:
                    continue
                q = quotes[symbol]
                fill_price, _ = _choose_paper_fill_price(side=side, quote_price_usd=q.last_price_usd,
                                                        quote_ask_usd=q.ask_usd, quote_bid_usd=q.bid_usd)
                remaining = qty if due else int(min(INITIAL * FRACTION, nav * FRACTION,
                                                   cash / (1 + COMMISSION)) / fill_price)
                if remaining == 0:
                    event['decisions'][-1]['action'] = 'SKIP_WHOLE_SHARE_UNFUNDED'
                    continue
                # The existing paper router also caps sells per trade; chunk risk-reducing exits.
                limit_qty = int(nav * FRACTION / fill_price)
                for _ in range(100):
                    if remaining <= 0:
                        break
                    order_qty = min(remaining, limit_qty)
                    require(order_qty > 0, 'PAPER_WHOLE_SHARE_CAP_UNFUNDED')
                    if side is Side.BUY:
                        require(order_qty * fill_price * (1 + COMMISSION) <= cash, 'PAPER_CASH_INSUFFICIENT')
                    else:
                        require(order_qty <= owned.get(symbol, 0), 'PAPER_OVERSELL')
                    rule = TradingRule(id=f'{POLICY}-{symbol}-{side.value.lower()}', symbol=symbol,
                                       stage=StrategyStage.BACKTEST, priority=10, enabled=True,
                                       trigger=PriceTrigger(direction='<=', threshold=q.last_price_usd, cooldown_seconds=60),
                                       action=Action(side=side, order_type=OrderType.LIMIT, qty=order_qty,
                                                     limit_price=str(fill_price)))
                    fill_started = self._check_fill_time(quotes, report, clock(), now, side)
                    outcome = await self.router.submit_order(
                        rule=rule, quote_price_usd=q.last_price_usd, quote_ask_usd=q.ask_usd,
                        quote_bid_usd=q.bid_usd, total_capital_usd=nav,
                        current_symbol_exposure_usd=owned.get(symbol, 0) * q.last_price_usd,
                        current_global_exposure_usd=sum(owned.get(s, 0) * quotes[s].last_price_usd for s in SYMBOLS))
                    fill_completed = self._check_fill_time(quotes, report, clock(), fill_started, side)
                    require(outcome.state == 'PAPER_FILLED', 'PAPER_ROUTER_ORDER_BLOCKED')
                    payload = json.loads(self.conn.execute("SELECT payload_json FROM audit_log WHERE correlation_id=? "
                                                         "AND event_type='ORDER_PAPER_FILLED'", (outcome.correlation_id,)).fetchone()[0])
                    fee = (order_qty * fill_price * COMMISSION).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
                    fill = dict(correlation_id=outcome.correlation_id, audit_payload=payload, commission_USD=str(fee),
                                decision_at_utc=fill_started.isoformat(), completed_at_utc=fill_completed.isoformat())
                    if side is Side.BUY:
                        fill['deadline_utc'], fill['planned_exit_utc'] = holding_deadlines(fill_completed)
                        cash -= order_qty * fill_price + fee
                        owned[symbol] = owned.get(symbol, 0) + order_qty
                    else:
                        cash += order_qty * fill_price - fee
                        owned[symbol] -= order_qty
                    require(cash >= 0, 'PAPER_CASH_INSUFFICIENT')
                    event['fills'].append(fill)
                    now = fill_completed
                    remaining -= order_qty
                require(remaining == 0, 'PAPER_ORDER_CHUNK_BOUND_EXHAUSTED')
            committed_at = clock()
            inputs.validate_consumption(quotes, report, committed_at)
            require(committed_at >= now, 'PAPER_CLOCK_REGRESSION')
            if event['fills']:
                final_side = Side.BUY if any(f['audit_payload']['side'] == 'BUY' for f in event['fills']) else Side.SELL
                self._check_fill_time(quotes, report, committed_at, now, final_side)
            event['commit_checked_at_utc'] = committed_at.isoformat()
            event['cash_after_USD'] = str(cash)
            raw = encode(event)
            self.conn.execute('INSERT INTO quote_paper_cycles(capture_sha256,previous_sha256,event_sha256,payload) '
                              'VALUES(?,?,?,?)', (capture, event['previous_sha256'], sha(raw), raw.decode()))
            after = replay(self.conn)
            require(after['positions'] == {s: v for s, v in owned.items() if v}, 'PAPER_POSITION_RECONCILIATION_FAILED')
            # Reconciliation can itself take time. A boundary crossed here also rolls back.
            commit_guard = clock()
            inputs.validate_consumption(quotes, report, commit_guard)
            require(commit_guard >= committed_at, 'PAPER_CLOCK_REGRESSION')
            if event['fills']:
                self._check_fill_time(quotes, report, commit_guard, committed_at, final_side)
            self.conn.execute('COMMIT')
            return dict(after, duplicate_capture=False, decisions=event['decisions'], session=session,
                        simulated_orders_this_capture=len(event['fills']))
        except BaseException:
            self.conn.execute('ROLLBACK')
            raise

    @staticmethod
    def _check_fill_time(quotes, report, now, previous, side):
        inputs.validate_consumption(quotes, report, now)
        require(now >= previous, 'PAPER_CLOCK_REGRESSION')
        session = regular_session(now)
        require(session['regular_open'] and all(
            datetime.fromisoformat(session['open_utc']) <= q.quoted_at_utc for q in quotes.values()),
            'PAPER_EXECUTION_SESSION_CHANGED')
        require(side is Side.SELL or session['entry_allowed'], 'PAPER_ENTRY_WINDOW_CLOSED')
        return now
