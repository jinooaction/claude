"""Price-only local handoff and configurable paper Quote provider; no broker writes."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src" if (ROOT / "src").is_dir() else ROOT / "source/src"))

from auto_invest.broker.models import Quote  # noqa: E402

SYMBOL_PATTERN = re.compile(r"[A-Z][A-Z0-9]{0,9}")
QUOTE_PATH = "/uapi/overseas-price/v1/quotations/price"
FIELDS = {"last_USD", "bid_USD", "ask_USD", "exchange", "observed_at_utc",
          "source_trade_time", "source_latency_verified", "source_response_sha256"}


def symbols(value) -> tuple[str, ...]:
    items = tuple(value.split(",") if isinstance(value, str) else value)
    if (not 1 <= len(items) <= 100 or len(set(items)) != len(items)
            or any(not isinstance(s, str) or not SYMBOL_PATTERN.fullmatch(s) for s in items)):
        raise ValueError("SYMBOL_CONFIGURATION_INVALID")
    return items


def utc(value) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.utcoffset() is None:
        raise ValueError("TIMEZONE_REQUIRED")
    return parsed.astimezone(UTC)


def price(value, *, optional=False):
    if optional and value is None:
        return None
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", value):
        raise ValueError("PRICE_INVALID")
    number = Decimal(value)
    if not number.is_finite() or number <= 0:
        raise ValueError("PRICE_INVALID")
    return number


def read_json(path: Path) -> dict:
    with path.open("rb") as handle:
        raw = handle.read(131073)
    if len(raw) > 131072:
        raise ValueError("HANDOFF_TOO_LARGE")
    return json.loads(raw)


def make_handoff(result: dict, environment: str, requested, *, emitted_at=None) -> dict:
    requested = symbols(requested)
    if environment not in {"production", "paper"}:
        raise ValueError("QUOTE_ENVIRONMENT_INVALID")
    quotes = {}
    unknown = {}
    for symbol in requested:
        row = result.get("quotes", {}).get(symbol)
        if row is None:
            reason = result.get("unknown", {}).get(symbol, "QUOTE_UNAVAILABLE")
            unknown[symbol] = reason if re.fullmatch(r"[A-Z_]{1,80}", reason) else "QUOTE_UNAVAILABLE"
        else:
            # Never export arbitrary headers, authentication values, or raw bodies.
            quotes[symbol] = {field: row.get(field) for field in FIELDS}
    return {
        "schema_version": 2,
        "source": {"kind": "KIS_REST_CURRENT_QUOTE", "environment": environment,
                   "endpoint": QUOTE_PATH, "tr_id": "HHDFS00000300"},
        "emitted_at_utc": (emitted_at or datetime.now(UTC)).isoformat(),
        "requested_symbols": list(requested), "quotes": quotes, "unknown": unknown,
        "quote_request_attempts": result.get("quote_request_attempts", 0),
        "execution_mode": "PAPER_INPUT_ONLY", "broker_orders_enabled": False,
    }


def write_handoff(path: Path, data: dict) -> None:
    """Atomic fixed-name price export, preventing an old valid file on failed cycles."""
    if path.name != "quote-handoff.json" or path.is_symlink():
        raise ValueError("HANDOFF_OUTPUT_MUST_BE_QUOTE_HANDOFF_JSON_NO_SYMLINK")
    raw = (json.dumps(data, ensure_ascii=False, sort_keys=True) + "\n").encode()
    fd, temp = tempfile.mkstemp(prefix=".quote-handoff-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


class PaperQuoteProvider:
    """Implements existing async quote_provider and latest_quote interfaces.

    Every lookup re-reads the atomic export and checks time against the consumer
    clock. Response freshness does not establish exchange trade freshness.
    """

    def __init__(self, path: Path, config: dict, *, clock=lambda: datetime.now(UTC)):
        self.path, self.clock = path, clock
        if set(config) != {"instruments", "max_response_age_seconds", "require_trade_time"}:
            raise ValueError("PAPER_CONFIG_INVALID")
        age = config["max_response_age_seconds"]
        if type(age) is not int or not 1 <= age <= 3600 or type(config["require_trade_time"]) is not bool:
            raise ValueError("PAPER_CONFIG_INVALID")
        self.max_age, self.require_trade_time = age, config["require_trade_time"]
        items = config["instruments"]
        symbols([item["symbol"] for item in items])
        self.instruments = {}
        for item in items:
            if (set(item) != {"symbol", "product", "currency", "quote_market"}
                    or item["product"] not in {"US_STOCK", "US_ETF"}
                    or item["currency"] != "USD" or item["quote_market"] not in {"NAS", "NYS", "AMS"}):
                raise ValueError("UNSUPPORTED_PRODUCT_CURRENCY_OR_QUOTE_MARKET")
            self.instruments[item["symbol"]] = dict(item)

    def evaluate(self) -> tuple[dict[str, Quote], dict]:
        accepted, unknown, details = {}, {}, {}
        try:
            data = read_json(self.path)
            if (set(data) != {"schema_version", "source", "emitted_at_utc", "requested_symbols",
                              "quotes", "unknown", "quote_request_attempts", "execution_mode", "broker_orders_enabled"}
                    or type(data["schema_version"]) is not int or data["schema_version"] != 2
                    or type(data["quote_request_attempts"]) is not int
                    or not 0 <= data["quote_request_attempts"] <= 3 * len(data["requested_symbols"])
                    or data["execution_mode"] != "PAPER_INPUT_ONLY"
                    or data["broker_orders_enabled"] is not False):
                raise ValueError("HANDOFF_SCHEMA_INVALID")
            source = data["source"]
            if (set(source) != {"kind", "environment", "endpoint", "tr_id"}
                    or source["kind"] != "KIS_REST_CURRENT_QUOTE"
                    or source["environment"] not in {"production", "paper"}
                    or source["endpoint"] != QUOTE_PATH or source["tr_id"] != "HHDFS00000300"):
                raise ValueError("HANDOFF_SOURCE_INVALID")
            requested = set(symbols(data["requested_symbols"]))
            if (not isinstance(data["quotes"], dict) or not isinstance(data["unknown"], dict)
                    or set(data["quotes"]) & set(data["unknown"])
                    or set(data["quotes"]) | set(data["unknown"]) != requested):
                raise ValueError("HANDOFF_COVERAGE_INVALID")
            now = self.clock()
            if now.utcoffset() is None:
                raise ValueError("CONSUMER_CLOCK_TIMEZONE_REQUIRED")
            emitted = utc(data["emitted_at_utc"])
            if not 0 <= (now - emitted).total_seconds() <= self.max_age:
                raise ValueError("HANDOFF_EMISSION_STALE_OR_FUTURE")
            digest = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
            for symbol, instrument in self.instruments.items():
                try:
                    if symbol not in data["quotes"]:
                        raise ValueError("QUOTE_MISSING_OR_COLLECTION_FAILED")
                    row = data["quotes"][symbol]
                    if set(row) != FIELDS or row["source_latency_verified"] is not False:
                        raise ValueError("QUOTE_SCHEMA_INVALID")
                    if row["exchange"] != instrument["quote_market"]:
                        raise ValueError("QUOTE_MARKET_MISMATCH")
                    observed = utc(row["observed_at_utc"])
                    age = (now - observed).total_seconds()
                    if observed > emitted or not 0 <= age <= self.max_age:
                        raise ValueError("QUOTE_RESPONSE_STALE_OR_FUTURE")
                    if not re.fullmatch(r"[0-9a-f]{64}", row["source_response_sha256"] or ""):
                        raise ValueError("RESPONSE_PROVENANCE_MISSING")
                    trade = utc(row["source_trade_time"]) if row["source_trade_time"] is not None else None
                    if trade is None and self.require_trade_time:
                        raise ValueError("SOURCE_TRADE_TIME_UNKNOWN")
                    if trade is not None and (trade > observed or not 0 <= (now - trade).total_seconds() <= self.max_age):
                        raise ValueError("SOURCE_TRADE_TIME_STALE_OR_FUTURE")
                    accepted[symbol] = Quote(
                        symbol=symbol, last_price_usd=price(row["last_USD"]),
                        bid_usd=price(row["bid_USD"], optional=True),
                        ask_usd=price(row["ask_USD"], optional=True),
                        quoted_at_utc=observed, resolved_market=row["exchange"],
                    )
                    if (accepted[symbol].bid_usd is not None and accepted[symbol].ask_usd is not None
                            and accepted[symbol].bid_usd > accepted[symbol].ask_usd):
                        del accepted[symbol]
                        raise ValueError("CROSSED_BID_ASK")
                    details[symbol] = dict(response_age_seconds=age, source_trade_time=row["source_trade_time"],
                                           trade_freshness="UNKNOWN" if trade is None else "WITHIN_LIMIT",
                                           response_sha256=row["source_response_sha256"])
                except (ValueError, TypeError, AttributeError, KeyError):
                    unknown[symbol] = "QUOTE_INPUT_REJECTED"
                    # A code, never raw input or authentication-like values.
                    error = sys.exc_info()[1]
                    if isinstance(error, ValueError) and re.fullmatch(r"[A-Z_]{1,80}", str(error)):
                        unknown[symbol] = str(error)
            return accepted, dict(phase="READY" if not unknown else "PARTIAL_OR_BLOCKED",
                                  accepted_symbols=list(accepted), unknown=unknown, quote_details=details,
                                  handoff_projection_sha256=digest, source=source,
                                  paper_input_only=True, real_time_verified=False, broker_orders_enabled=False)
        except (OSError, ValueError, TypeError, AttributeError, KeyError):
            return {}, dict(phase="BLOCKED", accepted_symbols=[],
                            unknown={s: "HANDOFF_UNAVAILABLE_OR_INVALID" for s in self.instruments},
                            paper_input_only=True, real_time_verified=False, broker_orders_enabled=False)

    @property
    def available(self) -> bool:
        return bool(self.evaluate()[0])

    def latest_quote(self, symbol: str) -> Quote | None:
        return self.evaluate()[0].get(symbol)

    async def __call__(self, symbol: str) -> Quote:
        quote = self.latest_quote(symbol)
        if quote is None:
            raise ValueError("PAPER_QUOTE_UNAVAILABLE")
        return quote

    def for_paper_router(self, router):
        """Bind to the existing router while refusing a live router on every call."""
        async def provide(symbol):
            if getattr(router, "paper_mode", None) is not True:
                raise ValueError("PAPER_ROUTER_REQUIRED")
            quote = await self(symbol)
            if getattr(router, "paper_mode", None) is not True:
                raise ValueError("PAPER_ROUTER_REQUIRED")
            return quote

        return provide


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    try:
        provider = PaperQuoteProvider(args.snapshot, read_json(args.config))
        result = provider.evaluate()[1]
    except (ValueError, TypeError, AttributeError, KeyError, OSError):
        result = dict(phase="BLOCKED", reason="PAPER_CONFIGURATION_INVALID")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["phase"] == "READY" else 2


if __name__ == "__main__":
    raise SystemExit(main())
