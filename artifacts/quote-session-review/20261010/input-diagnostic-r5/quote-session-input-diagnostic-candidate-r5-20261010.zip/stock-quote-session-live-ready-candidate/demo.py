#!/usr/bin/env python3
"""키 없는 합성 파일 재생. 기존 v14 모의 원장·반복 루프 재사용."""

import argparse
import asyncio
import hashlib
import json
import signal
import sys
from datetime import timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "source/src"))

from auto_invest.analytics import intraday_operator as lifecycle  # noqa: E402
from auto_invest.analytics.intraday_runtime import PaperRuntime, read_status  # noqa: E402
from auto_invest.execution.offline_network import deny_network  # noqa: E402
from auto_invest.market_data.intraday import DataError, utc  # noqa: E402

MODE = "SYNTHETIC_FILE_REPLAY_UNVALIDATED"
NOTICE = "합성 자료 작동 데모 / 실시간 주식 시세 아님 / 미검증 전략"


def config():
    path = ROOT / "source/specs/177-intraday-paper-challenger/contracts/intraday-preregistration.json"
    result = json.loads(path.read_text())
    result["candidates"] = [
        c for c in result["candidates"] if c["candidate_id"] == "intraday-orb-15m-fast"
    ]
    if len(result["candidates"]) != 1:
        raise DataError("DEMO_STRATEGY_MISSING")
    return result


def fixture():
    raw = (ROOT / "synthetic-bars.json").read_bytes()
    pin = (ROOT / "synthetic-bars.sha256").read_text().strip()
    if hashlib.sha256(raw).hexdigest() != pin:
        raise DataError("DEMO_FIXTURE_HASH_MISMATCH")
    result = json.loads(raw)
    if result.get("source") != "INVENTED_SYNTHETIC_ONLY" or result.get("fixture_only") is not True:
        raise DataError("DEMO_FIXTURE_REQUIRED")
    return result["frames"], pin


def paper_status(root):
    path = root / "paper.db"
    initial = {"processed_bars": 0, "cash_USD": "100000", "positions": {},
               "pending_simulated_orders": {}, "simulated_fills": 0}
    if not path.exists():
        return initial
    summary = read_status(path)
    if not summary["accounts"]:
        return initial
    account = next(iter(summary["accounts"].values()))
    import sqlite3

    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as conn:
        payload = json.loads(conn.execute(
            "SELECT payload FROM intraday_events ORDER BY id DESC LIMIT 1"
        ).fetchone()[0])
    state = next(iter(payload["state"]["accounts"].values()))
    return {"processed_bars": summary["processed_bars"], "last_simulated_bar": summary["last_bar"],
            "cash_USD": account["cash"], "positions": account["positions"],
            "pending_simulated_orders": state["pending"],
            "simulated_fills": summary["simulated_fills"], "halt_reasons": summary["halt_reasons"]}


def status(root):
    return dict(lifecycle.status(root, mode=MODE), paper=paper_status(root),
                market_connected=False, live_eligible=False, strategy_validated=False,
                stop_behavior="PAUSE_AND_PRESERVE_POSITIONS")


async def start(root, cycles):
    frames, pin = fixture()
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    async def cycle():
        runtime = PaperRuntime(root / "paper.db", config(), "invented-file:" + pin, True, "replay")
        try:
            cursor = runtime.status()["processed_bars"]
            for frame in frames[cursor:cursor + 20]:
                stamp = utc(frame[0]["timestamp_utc"])
                runtime.process(frame, stamp + timedelta(minutes=5))
            return dict(paper_status(root), orders_submitted=0,
                        replay_complete=runtime.status()["processed_bars"] == len(frames))
        finally:
            runtime.close()

    try:
        # Keep existing 60-second polling and process-lock/stop/restart semantics.
        result = await lifecycle.run(root, cycle=cycle, poll_seconds=60, cycles=cycles,
                                     stop_event=stop, mode=MODE)
        if result["phase"] in {"FAILED", "ALREADY_RUNNING"}:
            return result
        return status(root)
    finally:
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.remove_signal_handler(sig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("start", "stop", "status"))
    parser.add_argument("--root", type=Path, default=ROOT / "state")
    parser.add_argument("--cycles", type=int, default=0, help="0=중지할 때까지, 1=한 차례 재생")
    args = parser.parse_args()
    try:
        with deny_network():
            if args.command == "start":
                result = asyncio.run(start(args.root, args.cycles))
            elif args.command == "stop":
                result = dict(lifecycle.request_stop(args.root), mode=MODE)
            else:
                result = status(args.root)
    except Exception as exc:
        result = {"phase": "FAILED", "mode": MODE, "reason": str(exc), "orders_submitted": 0}
    result = {"notice": NOTICE, **result}
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    return 2 if result.get("phase") in {"FAILED", "ALREADY_RUNNING"} else 0


if __name__ == "__main__":
    raise SystemExit(main())
