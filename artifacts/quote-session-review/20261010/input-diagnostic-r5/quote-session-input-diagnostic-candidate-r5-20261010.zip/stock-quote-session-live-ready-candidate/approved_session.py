"""Root-granted existing-token quote session; default blocked, mock injected in tests."""

import asyncio
from contextlib import nullcontext
import json
import re
import uuid as uuid
from datetime import timedelta
from pathlib import Path

import httpx
import one_shot_gate as gate

from one_shot_gate import REAL_ORIGIN, MOCK_ORIGIN, Refusal, real_transport

import demo
import kis_quotes as legacy
import quote_session as common
import server_integrate_once as security
from auto_invest.broker import overseas
from quote_handoff import make_handoff

Clock, FakeClock = common.Clock, common.FakeClock
require, digest, encode, utc = common.require, common.digest, common.encode, common.utc
PROFILE = dict(
    max_attempts=3,
    max_HTTP_per_capture=10,
    max_HTTP=30,
    max_seconds=180,
    capture_spacing=60,
    HTTP_spacing=1,
)
CONTRACT = "KIS_QUOTE_SESSION_V2_EXISTING_TOKEN_APPROVED"
ENVIRONMENT = "production"
INVENTED_AUTH = (
    "invented-session-key",
    "invented-session-secret",
    "invented-session-token",
)
MARKETS = dict(AAPL="NAS", SCHX="AMS", SPTI="AMS", IAUM="AMS")
PLAN = [
    (s, m)
    for s in common.inputs.SYMBOLS
    for m in (("NAS",) if s == "AAPL" else ("NAS", "NYS", "AMS"))
]


def pin():
    return digest(Path(__file__).read_bytes())


def safe_body(raw, secrets=(), *, mock, diagnostic=None):
    try:
        return security.quote_body(raw, secrets, mock=mock, diagnostic=diagnostic)
    except security.Refusal as exc:
        raise demo.DataError(str(exc)) from None
    except Exception:
        raise demo.DataError("KIS_SESSION_RESPONSE_SCHEMA_DENIED") from None


class Boundary(httpx.AsyncBaseTransport):
    """Reserve calls, then recheck at the granted real or injected mock boundary."""

    def __init__(self, publisher, inner, *, dispatch_ready=lambda: True):
        require(
            type(inner)
            is (
                httpx.MockTransport
                if publisher.permit.mock
                else httpx.AsyncHTTPTransport
            ),
            "APPROVED_TRANSPORT_TYPE_REQUIRED",
        )
        self.owner, self.inner, self.dispatch_ready = publisher, inner, dispatch_ready
        self.reserved = self.entered = self.completed = 0
        self.local = 0
        self.records = []
        self.last_completed = None
        self.failed = False
        self.busy = False

    async def handle_async_request(self, request):
        require(
            not self.busy and not self.failed, "KIS_SESSION_TRANSPORT_TERMINAL_OR_BUSY"
        )
        self.busy = True
        owner = self.owner
        try:
            owner.diagnostic = security.input_diagnostic("REQUEST_GUARD")
            owner.remaining()
            require(owner.collecting, "KIS_SESSION_NO_ACTIVE_CAPTURE")
            await legacy.quote_guard(request, symbols=common.inputs.SYMBOLS)
            require(
                str(request.url).startswith(
                    legacy.ENDPOINTS[ENVIRONMENT] + legacy.QUOTE_PATH + "?"
                )
                and len(request.url.params.multi_items()) == 3
                and not request.content,
                "KIS_SESSION_REQUEST_DENIED",
            )
            require(self.local < 10 and self.reserved < 30, "KIS_SESSION_HTTP_CAP")
            symbol, market = PLAN[self.local]
            require(
                (request.url.params["SYMB"], request.url.params["EXCD"])
                == (symbol, market),
                "KIS_SESSION_REQUEST_ROUTE_CHANGED",
            )
            require(
                request.headers.get("appkey") == owner.auth.credentials[0]
                and request.headers.get("appsecret") == owner.auth.credentials[1]
                and request.headers.get("authorization")
                == "Bearer " + owner.auth.credentials[2],
                "EXISTING_AUTH_HEADERS_CHANGED",
            )
            self.reserved += 1
            security.diagnostic_stage(owner.diagnostic, "RESERVATION")
            number = self.reserved
            reserved_at = owner.clock.now()
            common.immutable(
                owner.root / f"http-reserved-{number:03d}.json",
                encode(
                    dict(
                        reservation=number,
                        attempt=owner.attempts,
                        symbol=symbol,
                        market=market,
                        method="GET",
                        endpoint=legacy.QUOTE_PATH,
                        reserved_at=reserved_at.isoformat(),
                        phase="RESERVED_ONLY",
                        actual_external_GET=0,
                    )
                ),
            )
            # Reservation/fsync is not an HTTP execution. Recheck after it and after spacing.
            security.diagnostic_stage(owner.diagnostic, "DISPATCH_GUARD")
            owner.remaining()
            if self.last_completed is not None:
                require(
                    owner.clock.monotonic() >= self.last_completed,
                    "KIS_SESSION_CLOCK_REGRESSION",
                )
                delay = max(0, 1 - (owner.clock.monotonic() - self.last_completed))
                require(delay < owner.remaining(), "KIS_SESSION_DEADLINE")
                await owner.clock.sleep(delay)
            owner.remaining()
            require(self.dispatch_ready() is True, "KIS_SESSION_DISPATCH_NOT_READY")
            request_budget = min(10, owner.remaining())
            async with asyncio.timeout(request_budget):
                with demo.deny_network() if owner.permit.mock else nullcontext():
                    owner.remaining()
                    require(
                        self.dispatch_ready() is True, "KIS_SESSION_DISPATCH_NOT_READY"
                    )
                    sent = owner.clock.now()
                    owner.remaining()
                    security.diagnostic_stage(owner.diagnostic, "TRANSPORT")
                    delegate = self.inner.handle_async_request
                    # No guard/fsync/await occurs between charging and calling the delegate.
                    self.entered += 1
                    response = await delegate(request)
                    await response.aread()
            self.completed += 1
            security.diagnostic_http(owner.diagnostic, response.status_code)
            security.diagnostic_stage(owner.diagnostic, "POST_HTTP_GUARD")
            observed = owner.clock.now()
            self.last_completed = owner.clock.monotonic()
            require(sent <= observed, "KIS_SESSION_CLOCK_REGRESSION")
            record = dict(
                reservation=number,
                symbol=symbol,
                market=market,
                reserved_at=reserved_at.isoformat(),
                transport_entered_at=sent.isoformat(),
                response_completed_at=observed.isoformat(),
                HTTP_status=response.status_code,
                response_file=f"http-response-{number:03d}.json",
                response_sha256=digest(response.content),
            )
            common.immutable(
                owner.root / f"http-completed-{number:03d}.json", encode(record)
            )
            owner.remaining()
            security.diagnostic_stage(owner.diagnostic, "HTTP_STATUS")
            require(response.status_code == 200, "KIS_SESSION_HTTP_FAILED_NO_RETRY")
            body = safe_body(
                response.content, owner.auth.credentials, mock=owner.permit.mock,
                diagnostic=owner.diagnostic,
            )
            security.diagnostic_stage(owner.diagnostic, "MARKET_QUOTE")
            last = overseas._opt_price(body["output"].get("last"))
            quoted = last is not None and last.is_finite() and last > 0
            require(
                quoted == (market == MARKETS[symbol]),
                "KIS_SESSION_MARKET_OR_QUOTE_UNAVAILABLE",
            )
            record["outcome"] = "QUOTE" if quoted else "EMPTY_MARKET_PROBE"
            security.diagnostic_stage(owner.diagnostic, "RESPONSE_PERSISTENCE")
            common.immutable(owner.root / record["response_file"], response.content)
            self.records.append(record)
            self.local += 1
            security.diagnostic_stage(owner.diagnostic, "QUOTE_ACCEPTED")
            return response
        except BaseException:
            self.failed = True
            raise
        finally:
            self.busy = False


class NoRetryClient:
    def __init__(self, http):
        self.http = http

    async def request(self, method, url, **kwargs):
        response = await self.http.request(method, url, **kwargs)
        response.raise_for_status()
        return response


class ApprovedPublisher:
    """Actual adapter enabled only by a verified root grant; tests explicitly mock."""

    def __init__(self, root, *, permit, auth, transport=None, clock=None):
        self.root, self.clock = root, clock or Clock()
        self.permit, self.auth = permit, auth
        gate.require_integrated_permit(permit, self.clock.now())
        require(auth.permit is permit, "AUTH_GRANT_MISMATCH")
        auth.ready(self.clock.now())
        self.id = permit.data["run_id"]
        if permit.mock:
            require(
                type(transport) is httpx.MockTransport,
                "MOCK_TRANSPORT_INJECTION_REQUIRED",
            )
        elif transport is None:
            transport = real_transport(permit, self.clock.now())
        require(
            type(transport)
            is (httpx.MockTransport if permit.mock else httpx.AsyncHTTPTransport),
            "APPROVED_TRANSPORT_TYPE_REQUIRED",
        )
        root.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.start, self.mono = self.clock.now(), self.clock.monotonic()
        self.attempts = 0
        self.last_start = None
        self.entries = []
        self.state, self.collecting = "ACTIVE", False
        self.diagnostic = security.input_diagnostic()
        self.diagnostic_attempted = False
        self.diagnostic_written = False
        self.boundary = Boundary(
            self, transport, dispatch_ready=lambda: self.auth.ready(self.clock.now())
        )
        self.pointer()

    @property
    def external_completed(self):
        return 0 if self.permit.mock else self.boundary.completed

    def remaining(self):
        gate.require_integrated_permit(self.permit, self.clock.now())
        self.auth.ready(self.clock.now())
        now = self.clock.now()
        elapsed = self.clock.monotonic() - self.mono
        require(
            0 <= elapsed < 180
            and self.start <= now < self.start + timedelta(seconds=180),
            "KIS_SESSION_DEADLINE_OR_CLOCK",
        )
        return min(
            180 - elapsed, (self.start + timedelta(seconds=180) - now).total_seconds()
        )

    def pointer(self):
        common.publish_manifest(
            self.root,
            dict(
                contract=CONTRACT,
                session_id=self.id,
                started_at=self.start.isoformat(),
                deadline_at=(self.start + timedelta(seconds=180)).isoformat(),
                profile=PROFILE,
                input_kind=self.permit.input_kind,
                grant_sha256=self.permit.sha256,
                approval_id=self.permit.data["approval_id"],
                producer_sha256=pin(),
                state=self.state,
                published_at=self.clock.now().isoformat(),
                attempts_reserved=self.attempts,
                HTTP_reserved=self.boundary.reserved,
                HTTP_transport_entered=self.boundary.entered,
                HTTP_completed=self.boundary.completed,
                actual_external_GET=self.external_completed,
                captures=self.entries,
                orders_submitted=0,
            ),
        )

    def counters(self):
        return dict(
            attempts_reserved=self.attempts,
            HTTP_reserved=self.boundary.reserved,
            HTTP_transport_entered=self.boundary.entered,
            HTTP_completed=self.boundary.completed,
            actual_external_GET=self.external_completed,
            complete_captures=len(self.entries),
            state=self.state,
            unknown={s: "CAPTURE_ABORTED" for s in MARKETS}
            if self.state == "FAILED"
            else {},
            source_trade_time_verified=False,
            real_time_verified=False,
            token_issuance_or_refresh=False,
            orders_submitted=0,
        )

    def record_rejection(self, exc):
        if self.diagnostic_attempted:
            return
        self.diagnostic_attempted = True
        # Never inspect or serialize exception text, provider codes or message values.
        self.diagnostic["rejection"] = (
            "TOKEN_OR_GRANT_GUARD" if isinstance(exc, Refusal)
            else "INPUT_GUARD" if isinstance(exc, demo.DataError)
            else "OTHER_FAILURE"
        )
        security.public_input_diagnostic(self.diagnostic)
        common.immutable(self.root / "input-diagnostic.json", encode(self.diagnostic))
        self.diagnostic_written = True

    async def collect(self):
        require(
            self.state == "ACTIVE" and not self.collecting,
            "KIS_SESSION_PRODUCER_TERMINAL_OR_BUSY",
        )
        self.collecting = True
        try:
            self.diagnostic = security.input_diagnostic("CAPTURE_PRECHECK")
            self.remaining()
            require(self.attempts < 3, "KIS_SESSION_ATTEMPT_CAP")
            if self.last_start is not None:
                delay = max(0, 60 - (self.clock.monotonic() - self.last_start))
                require(delay < self.remaining(), "KIS_SESSION_DEADLINE")
                await self.clock.sleep(delay)
            self.remaining()
            self.attempts += 1
            began = self.clock.now()
            common.immutable(
                self.root / f"attempt-{self.attempts:03d}.json",
                encode(
                    dict(
                        attempt=self.attempts,
                        reserved_at=began.isoformat(),
                        phase="ATTEMPT_RESERVED_ONLY",
                    )
                ),
            )
            self.remaining()
            self.last_start, self.boundary.local = self.clock.monotonic(), 0
            offset, rows = len(self.boundary.records), {}
            async with httpx.AsyncClient(
                base_url=legacy.ENDPOINTS[ENVIRONMENT],
                transport=self.boundary,
                timeout=10,
                follow_redirects=False,
                trust_env=False,
            ) as http:
                client = NoRetryClient(http)
                for symbol in common.inputs.SYMBOLS:
                    quote = await overseas.get_quote_resolving_market(
                        client,
                        access_token=self.auth.credentials[2],
                        app_key=self.auth.credentials[0],
                        app_secret=self.auth.credentials[1],
                        symbol=symbol,
                        markets=("NAS",) if symbol == "AAPL" else ("NAS", "NYS", "AMS"),
                    )
                    record = self.boundary.records[-1]
                    security.diagnostic_stage(self.diagnostic, "MARKET_QUOTE")
                    require(
                        quote.resolved_market == MARKETS[symbol],
                        "KIS_SESSION_MARKET_CHANGED",
                    )
                    rows[symbol] = dict(
                        last_USD=str(quote.last_price_usd),
                        bid_USD=str(quote.bid_usd)
                        if quote.bid_usd is not None
                        else None,
                        ask_USD=str(quote.ask_usd)
                        if quote.ask_usd is not None
                        else None,
                        exchange=quote.resolved_market,
                        observed_at_utc=record["response_completed_at"],
                        source_response_sha256=record["response_sha256"],
                        source_trade_time=None,
                        source_latency_verified=False,
                    )
            security.diagnostic_stage(self.diagnostic, "CAPTURE_BUILD")
            self.remaining()
            records = self.boundary.records[offset:]
            require(len(records) == 10, "KIS_SESSION_CAPTURE_HTTP_COUNT")
            emitted_at = self.clock.now()
            raw = encode(
                make_handoff(
                    dict(quotes=rows, quote_request_attempts=10),
                    ENVIRONMENT,
                    common.inputs.SYMBOLS,
                    emitted_at=emitted_at,
                )
            )
            quotes, report = provider(raw, self.clock.now)
            require(
                report["phase"] == "READY" and len(quotes) == 4,
                "KIS_SESSION_PARTIAL_CAPTURE",
            )
            sequence = len(self.entries) + 1
            proof = dict(
                contract=CONTRACT,
                session_id=self.id,
                sequence=sequence,
                profile=PROFILE,
                producer_sha256=pin(),
                input_kind=self.permit.input_kind,
                grant_sha256=self.permit.sha256,
                approval_id=self.permit.data["approval_id"],
                status="SUCCESS",
                snapshot_sha256=digest(raw),
                previous_receipt_sha256=self.entries[-1]["receipt_sha256"]
                if self.entries
                else common.ZERO,
                attempt_started_at=began.isoformat(),
                emitted_at=emitted_at.isoformat(),
                requests=records,
                attempt=self.attempts,
                HTTP_reserved=self.boundary.reserved,
                HTTP_transport_entered=self.boundary.entered,
                HTTP_completed=self.boundary.completed,
                actual_external_GET=self.external_completed,
                orders_submitted=0,
                token_issuance_or_refresh=False,
                source_trade_time_verified=False,
                real_time_verified=False,
            )
            receipt_raw = encode(proof)
            snapshot_name, receipt_name = (
                f"capture-{sequence:03d}.json",
                f"receipt-{sequence:03d}.json",
            )
            common.immutable(self.root / snapshot_name, raw)
            common.immutable(self.root / receipt_name, receipt_raw)
            self.remaining()
            self.entries.append(
                dict(
                    sequence=sequence,
                    snapshot=snapshot_name,
                    receipt=receipt_name,
                    snapshot_sha256=digest(raw),
                    receipt_sha256=digest(receipt_raw),
                )
            )
            if self.attempts == 3:
                self.state = "COMPLETED"
            self.pointer()
            return proof
        except BaseException as exc:
            self.state = "FAILED"
            common.immutable(self.root / "terminal.json", encode(self.counters()))
            self.pointer()
            self.record_rejection(exc)
            raise
        finally:
            self.collecting = False


class SingleGetDiagnostic:
    """Separate purpose: AAPL/NAS once, no fallback/capture/paper/raw response file."""

    def __init__(self, root, *, permit, auth, transport=None, clock=None):
        self.clock = clock or Clock()
        require(type(permit) is gate.DiagnosticPermit, "DIAGNOSTIC_PERMIT_REQUIRED")
        permit.check(self.clock.now())
        require(auth.permit is permit, "AUTH_GRANT_MISMATCH")
        auth.ready(self.clock.now())
        require(permit.mock or root == gate.BASE / "data/quote-diagnostic-review" / permit.data["run_id"] / "worker/captures",
                "GRANTED_OUTPUT_PATH_REQUIRED")
        if permit.mock:
            require(type(transport) is httpx.MockTransport, "MOCK_TRANSPORT_INJECTION_REQUIRED")
        elif transport is None:
            transport = real_transport(permit, self.clock.now())
        require(type(transport) is (httpx.MockTransport if permit.mock else httpx.AsyncHTTPTransport),
                "APPROVED_TRANSPORT_TYPE_REQUIRED")
        root.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.root, self.permit, self.auth, self.inner = root, permit, auth, transport
        self.start, self.mono = self.clock.now(), self.clock.monotonic()
        self.used = self.diagnostic_attempted = self.diagnostic_written = False
        self.reserved = self.entered = self.completed = 0
        self.diagnostic = security.single_get_diagnostic()
        self.dispatch_ready = lambda: self.auth.ready(self.clock.now())

    def remaining(self):
        self.auth.ready(self.clock.now())
        now, elapsed = self.clock.now(), self.clock.monotonic() - self.mono
        require(0 <= elapsed < 15 and self.start <= now < self.start + timedelta(seconds=15),
                "DIAGNOSTIC_DEADLINE_OR_CLOCK")
        return min(15 - elapsed, (self.start + timedelta(seconds=15) - now).total_seconds())

    def record(self, exc=None):
        if self.diagnostic_attempted:
            return
        self.diagnostic_attempted = True
        self.diagnostic["outcome"] = "ACCEPTED" if exc is None else "REJECTED"
        self.diagnostic["rejection"] = (
            "NONE" if exc is None else "TOKEN_OR_GRANT_GUARD" if isinstance(exc, Refusal)
            else "INPUT_GUARD" if isinstance(exc, demo.DataError) else "OTHER_FAILURE"
        )
        security.public_single_get_diagnostic(self.diagnostic)
        common.immutable(self.root / "input-diagnostic.json", encode(self.diagnostic))
        self.diagnostic_written = True

    async def run(self):
        require(not self.used, "DIAGNOSTIC_ALREADY_TERMINAL")
        self.used = True  # Even a guard or storage failure cannot permit a second call.
        try:
            self.remaining()
            request = httpx.Request(
                "GET", legacy.ENDPOINTS[ENVIRONMENT] + legacy.QUOTE_PATH,
                params={"AUTH": "", "EXCD": "NAS", "SYMB": "AAPL"},
                headers=overseas._kis_headers(access_token=self.auth.credentials[2],
                    app_key=self.auth.credentials[0], app_secret=self.auth.credentials[1],
                    tr_id=overseas.TR_ID_QUOTE),
            )
            security.diagnostic_stage(self.diagnostic, "REQUEST_GUARD")
            await legacy.quote_guard(request, symbols=("AAPL",))
            require(str(request.url).startswith(legacy.ENDPOINTS[ENVIRONMENT] + legacy.QUOTE_PATH + "?")
                    and request.url.path == legacy.QUOTE_PATH
                    and request.url.params.multi_items() == [("AUTH", ""), ("EXCD", "NAS"), ("SYMB", "AAPL")]
                    and not request.content, "DIAGNOSTIC_REQUEST_SCOPE")
            require(request.headers.get("appkey") == self.auth.credentials[0]
                    and request.headers.get("appsecret") == self.auth.credentials[1]
                    and request.headers.get("authorization") == "Bearer " + self.auth.credentials[2],
                    "EXISTING_AUTH_HEADERS_CHANGED")
            require(self.reserved == self.entered == self.completed == 0, "DIAGNOSTIC_HTTP_CAP")
            security.diagnostic_stage(self.diagnostic, "RESERVATION")
            self.reserved = 1
            security.diagnostic_stage(self.diagnostic, "DISPATCH_GUARD")
            self.remaining()
            require(self.dispatch_ready() is True, "KIS_SESSION_DISPATCH_NOT_READY")
            budget = min(5, self.remaining())
            async with asyncio.timeout(budget):
                with demo.deny_network() if self.permit.mock else nullcontext():
                    self.remaining()
                    require(self.dispatch_ready() is True, "KIS_SESSION_DISPATCH_NOT_READY")
                    sent = self.clock.now()
                    self.remaining()
                    security.diagnostic_stage(self.diagnostic, "TRANSPORT")
                    delegate = self.inner.handle_async_request
                    self.entered = 1
                    response = await delegate(request)
                    await response.aread()
            self.completed = 1
            security.diagnostic_http(self.diagnostic, response.status_code)
            security.diagnostic_stage(self.diagnostic, "POST_HTTP_GUARD")
            require(sent <= self.clock.now(), "KIS_SESSION_CLOCK_REGRESSION")
            self.remaining()
            security.diagnostic_stage(self.diagnostic, "HTTP_STATUS")
            require(response.status_code == 200, "KIS_SESSION_HTTP_FAILED_NO_RETRY")
            body = safe_body(response.content, self.auth.credentials, mock=self.permit.mock,
                             diagnostic=self.diagnostic)
            security.diagnostic_stage(self.diagnostic, "MARKET_QUOTE")
            last = overseas._opt_price(body["output"].get("last"))
            require(last is not None and last.is_finite() and last > 0,
                    "KIS_SESSION_MARKET_OR_QUOTE_UNAVAILABLE")
            self.remaining()
            security.diagnostic_stage(self.diagnostic, "QUOTE_ACCEPTED")
            self.record()
            self.remaining()
        except BaseException as exc:
            self.record(exc)
            raise


provider = common.provider


def read_session(path, now):
    require(not path.parent.is_symlink(), "KIS_SESSION_ROOT_SYMLINK")
    read = common.inputs.read_bytes

    def loads(raw):
        return json.loads(raw, object_pairs_hook=common.inputs.unique)

    manifest = loads(read(path))
    fields = {
        "contract",
        "session_id",
        "started_at",
        "deadline_at",
        "profile",
        "input_kind",
        "producer_sha256",
        "state",
        "published_at",
        "attempts_reserved",
        "HTTP_reserved",
        "HTTP_transport_entered",
        "HTTP_completed",
        "actual_external_GET",
        "captures",
        "orders_submitted",
        "grant_sha256",
        "approval_id",
    }
    require(
        set(manifest) == fields
        and manifest["contract"] == CONTRACT
        and encode(manifest["profile"]) == encode(PROFILE)
        and manifest["producer_sha256"] == pin()
        and manifest["input_kind"] in {REAL_ORIGIN, MOCK_ORIGIN},
        "KIS_SESSION_CONTRACT_INVALID",
    )
    require(
        re.fullmatch("[a-f0-9]{32}", manifest["session_id"]), "KIS_SESSION_ID_INVALID"
    )
    for key in (
        "attempts_reserved",
        "HTTP_reserved",
        "HTTP_transport_entered",
        "HTTP_completed",
        "actual_external_GET",
        "orders_submitted",
    ):
        require(type(manifest[key]) is int, "KIS_SESSION_COUNTER_TYPE")
    start, published, deadline = (
        utc(manifest["started_at"]),
        utc(manifest["published_at"]),
        utc(manifest["deadline_at"]),
    )
    require(
        deadline == start + timedelta(seconds=180)
        and start <= published < deadline
        and start <= now < deadline
        and 0 <= (now - published).total_seconds() <= 120,
        "KIS_SESSION_STALE_OR_FUTURE",
    )
    require(manifest["state"] in ("ACTIVE", "COMPLETED"), "KIS_SESSION_PRODUCER_FAILED")
    require(
        re.fullmatch("[a-f0-9]{64}", manifest["grant_sha256"])
        and re.fullmatch("[a-f0-9]{32}", manifest["approval_id"]),
        "SESSION_GRANT_ID_INVALID",
    )
    count = len(manifest["captures"])
    actual = count * 10 if manifest["input_kind"] == REAL_ORIGIN else 0
    require(
        0 <= count <= 3
        and manifest["attempts_reserved"] == count
        and manifest["HTTP_reserved"]
        == manifest["HTTP_transport_entered"]
        == manifest["HTTP_completed"]
        == count * 10
        and manifest["actual_external_GET"] == actual
        and manifest["orders_submitted"] == 0
        and (manifest["state"] != "COMPLETED" or count == 3),
        "KIS_SESSION_COUNTER_INVALID",
    )
    entries, previous, last_start, last_observed = [], common.ZERO, None, None
    receipt_fields = {
        "contract",
        "session_id",
        "sequence",
        "profile",
        "producer_sha256",
        "input_kind",
        "status",
        "snapshot_sha256",
        "previous_receipt_sha256",
        "attempt_started_at",
        "emitted_at",
        "requests",
        "attempt",
        "HTTP_reserved",
        "HTTP_transport_entered",
        "HTTP_completed",
        "actual_external_GET",
        "orders_submitted",
        "token_issuance_or_refresh",
        "source_trade_time_verified",
        "real_time_verified",
        "grant_sha256",
        "approval_id",
    }
    request_fields = {
        "reservation",
        "symbol",
        "market",
        "reserved_at",
        "transport_entered_at",
        "response_completed_at",
        "HTTP_status",
        "response_file",
        "response_sha256",
        "outcome",
    }
    for index, item in enumerate(manifest["captures"], 1):
        require(
            set(item)
            == {"sequence", "snapshot", "receipt", "snapshot_sha256", "receipt_sha256"}
            and type(item["sequence"]) is int
            and item["sequence"] == index
            and item["snapshot"] == f"capture-{index:03d}.json"
            and item["receipt"] == f"receipt-{index:03d}.json",
            "KIS_SESSION_SEQUENCE_PATH_INVALID",
        )
        raw, receipt_raw = (
            read(path.parent / item["snapshot"]),
            read(path.parent / item["receipt"]),
        )
        require(
            digest(raw) == item["snapshot_sha256"]
            and digest(receipt_raw) == item["receipt_sha256"],
            "KIS_SESSION_PAIR_HASH",
        )
        proof = loads(receipt_raw)
        require(
            set(proof) == receipt_fields
            and proof["contract"] == CONTRACT
            and proof["session_id"] == manifest["session_id"]
            and encode(proof["profile"]) == encode(PROFILE)
            and proof["producer_sha256"] == pin()
            and proof["input_kind"] == manifest["input_kind"]
            and proof["grant_sha256"] == manifest["grant_sha256"]
            and proof["approval_id"] == manifest["approval_id"]
            and proof["status"] == "SUCCESS"
            and proof["previous_receipt_sha256"] == previous
            and proof["snapshot_sha256"] == digest(raw),
            "KIS_SESSION_RECEIPT_INVALID",
        )
        for key in (
            "sequence",
            "attempt",
            "HTTP_reserved",
            "HTTP_transport_entered",
            "HTTP_completed",
            "actual_external_GET",
            "orders_submitted",
        ):
            require(type(proof[key]) is int, "KIS_SESSION_COUNTER_TYPE")
        require(
            proof["sequence"] == proof["attempt"] == index
            and proof["HTTP_reserved"]
            == proof["HTTP_transport_entered"]
            == proof["HTTP_completed"]
            == index * 10
            and proof["actual_external_GET"]
            == (index * 10 if manifest["input_kind"] == REAL_ORIGIN else 0)
            and proof["orders_submitted"] == 0
            and all(
                proof[k] is False
                for k in (
                    "token_issuance_or_refresh",
                    "source_trade_time_verified",
                    "real_time_verified",
                )
            ),
            "KIS_SESSION_RECEIPT_COUNTER_INVALID",
        )
        began, emitted = utc(proof["attempt_started_at"]), utc(proof["emitted_at"])
        require(
            start <= began <= emitted <= published
            and (last_start is None or (began - last_start).total_seconds() >= 60),
            "KIS_SESSION_CAPTURE_SPACING",
        )
        require(len(proof["requests"]) == 10, "KIS_SESSION_HTTP_COUNT")
        selected = {}
        for local, (request, (symbol, market)) in enumerate(
            zip(proof["requests"], PLAN), 1
        ):
            number = (index - 1) * 10 + local
            require(
                set(request) == request_fields
                and type(request["reservation"]) is int
                and request["reservation"] == number
                and request["symbol"] == symbol
                and request["market"] == market
                and type(request["HTTP_status"]) is int
                and request["HTTP_status"] == 200
                and request["response_file"] == f"http-response-{number:03d}.json",
                "KIS_SESSION_HTTP_RECORD_INVALID",
            )
            reserved, sent, observed = (
                utc(request["reserved_at"]),
                utc(request["transport_entered_at"]),
                utc(request["response_completed_at"]),
            )
            require(
                began <= reserved <= sent <= observed <= emitted
                and (
                    last_observed is None or (sent - last_observed).total_seconds() >= 1
                ),
                "KIS_SESSION_HTTP_SPACING",
            )
            response_raw = read(path.parent / request["response_file"])
            require(
                digest(response_raw) == request["response_sha256"],
                "KIS_SESSION_HTTP_RESPONSE_HASH",
            )
            body = safe_body(response_raw, mock=manifest["input_kind"] == MOCK_ORIGIN)
            last = overseas._opt_price(body["output"].get("last"))
            quoted = last is not None and last.is_finite() and last > 0
            require(
                quoted == (market == MARKETS[symbol])
                and request["outcome"] == ("QUOTE" if quoted else "EMPTY_MARKET_PROBE"),
                "KIS_SESSION_HTTP_RESPONSE_SEMANTICS",
            )
            if quoted:
                selected[symbol] = (request, body["output"])
            last_observed = observed
        data = loads(raw)
        require(
            data["requested_symbols"] == list(common.inputs.SYMBOLS)
            and data["unknown"] == {}
            and data["quote_request_attempts"] == 10
            and data["emitted_at_utc"] == proof["emitted_at"]
            and data["source"]["environment"] == ENVIRONMENT
            and set(data["quotes"]) == set(MARKETS),
            "KIS_SESSION_SNAPSHOT_INVALID",
        )
        for symbol, (request, output) in selected.items():
            row = data["quotes"][symbol]

            def normalized(value):
                price = overseas._opt_price(value)
                return str(price) if price is not None else None

            require(
                row["observed_at_utc"] == request["response_completed_at"]
                and row["exchange"] == MARKETS[symbol]
                and row["source_response_sha256"] == request["response_sha256"]
                and row["last_USD"] == normalized(output.get("last"))
                and row["bid_USD"] == normalized(output.get("bidp"))
                and row["ask_USD"] == normalized(output.get("askp"))
                and row["source_trade_time"] is None
                and row["source_latency_verified"] is False,
                "KIS_SESSION_EXTRACTION_PROVENANCE",
            )
        previous, last_start = item["receipt_sha256"], began
        entries.append(dict(item, raw=raw, proof=proof))
    return manifest, entries


def verified_capture(entry, clock):
    quotes, report = common.verified_capture(entry, clock)
    return quotes, dict(
        report,
        quote_request_attempts=10,
        HTTP_reserved=entry["proof"]["HTTP_reserved"],
        HTTP_transport_entered=entry["proof"]["HTTP_transport_entered"],
        HTTP_completed=entry["proof"]["HTTP_completed"],
        actual_external_GET=entry["proof"]["actual_external_GET"],
    )
