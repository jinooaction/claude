"""Validate a price-only projection of an already published KIS smoke result.

No network, authentication files, remote commands, or trading imports. The log's
publication time is never promoted to the quote's observation/trade time.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

REQUIRED_SYMBOLS = ("SPY", "QQQ", "IWM", "TLT", "GLD")
SOURCE_URL = (
    "https://github.com/jinooaction/claude/blob/"
    "automation/kis-smoke-last-run/LAST_RUN.md"
)
PRICE = r"[0-9]+(?:\.[0-9]+)?"


def utc(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("TIMESTAMP_TIMEZONE_REQUIRED")
    return parsed.astimezone(UTC)


def exact_keys(value: dict, expected: set[str]) -> None:
    if not isinstance(value, dict) or set(value) != expected:
        raise ValueError("PROJECTION_SCHEMA_INVALID")


def inspect_projection(data: dict, *, required_symbols=REQUIRED_SYMBOLS) -> dict:
    if (not required_symbols or len(set(required_symbols)) != len(required_symbols)
            or any(not re.fullmatch(r"[A-Z][A-Z0-9]{0,9}", s) for s in required_symbols)):
        raise ValueError("SYMBOL_CONFIGURATION_INVALID")
    exact_keys(data, {"schema_version", "source", "metadata", "quote_lines"})
    if type(data["schema_version"]) is not int or data["schema_version"] != 1:
        raise ValueError("PROJECTION_SCHEMA_INVALID")
    source, meta = data["source"], data["metadata"]
    exact_keys(source, {"repository", "ref", "path", "blob_sha", "url",
                        "line_start", "line_end", "read_started_at_utc",
                        "read_completed_at_utc"})
    exact_keys(meta, {"code_commit", "snapshot_published_at_utc",
                      "smoke_state", "smoke_exit"})
    if (source["repository"], source["ref"], source["path"], source["url"]) != (
        "jinooaction/claude", "automation/kis-smoke-last-run", "LAST_RUN.md", SOURCE_URL
    ):
        raise ValueError("SOURCE_NOT_ALLOWED")
    for sha in (source["blob_sha"], meta["code_commit"]):
        if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{40}", sha):
            raise ValueError("SOURCE_SHA_INVALID")
    start, end = source["line_start"], source["line_end"]
    if type(start) is not int or type(end) is not int or not 1 <= start <= end <= 1000:
        raise ValueError("SOURCE_LINE_RANGE_INVALID")
    begin = utc(source["read_started_at_utc"])
    observed = utc(source["read_completed_at_utc"])
    published = utc(meta["snapshot_published_at_utc"])
    if begin > observed or published > observed:
        raise ValueError("TIMESTAMP_ORDER_INVALID")
    if (meta["smoke_state"] != "success" or type(meta["smoke_exit"]) is not int
            or meta["smoke_exit"] != 0):
        raise ValueError("SMOKE_NOT_SUCCESSFUL")
    if not isinstance(data["quote_lines"], list) or len(data["quote_lines"]) > 20:
        raise ValueError("QUOTE_LINES_INVALID")
    quotes, seen_lines = {}, set()

    def add(symbol: str, price: str, market: str | None, line: int) -> None:
        value = Decimal(price)
        if not value.is_finite() or value <= 0:
            raise ValueError("QUOTE_PRICE_INVALID")
        if symbol in quotes:
            raise ValueError("DUPLICATE_QUOTE")
        quotes[symbol] = {
            "symbol": symbol, "last_price_usd": price, "currency": "USD",
            "reported_market": market, "source_line": line,
            "quote_observed_at_utc": None, "source_trade_time_utc": None,
            "latency_verified": False,
        }

    for row in data["quote_lines"]:
        exact_keys(row, {"source_line", "text"})
        line, text = row["source_line"], row["text"]
        if type(line) is not int or not start <= line <= end or line in seen_lines:
            raise ValueError("SOURCE_LINE_INVALID")
        seen_lines.add(line)
        if not isinstance(text, str) or len(text) > 2000:
            raise ValueError("QUOTE_TEXT_INVALID")
        single = re.fullmatch(rf"Live AAPL quote: \$({PRICE})", text)
        if single:
            add("AAPL", single[1], None, line)
            continue
        prefix = "Execution proxy quotes: "
        if not text.startswith(prefix):
            raise ValueError("NON_PRICE_LINE_REJECTED")
        for part in text[len(prefix):].split(", "):
            match = re.fullmatch(rf"([A-Z]{{1,5}})=\$({PRICE})\((NAS|NYS|AMS)\)", part)
            if not match:
                raise ValueError("QUOTE_TEXT_INVALID")
            add(match[1], match[2], match[3], line)
    missing = [symbol for symbol in required_symbols if symbol not in quotes]
    return {
        "schema_version": 1, "mode": "PUBLISHED_DIAGNOSTIC_SNAPSHOT_ONLY",
        "source": source, "metadata": meta,
        "publication_to_read_seconds": (observed - published).total_seconds(),
        "quote_age_seconds": None,
        "diagnostic_quote_count": len(quotes),
        "required_symbols": list(required_symbols),
        "required_symbol_quote_count": len(required_symbols) - len(missing),
        "missing_required_symbols": missing,
        "unknowns": {symbol: "NOT_IN_PUBLISHED_SNAPSHOT" for symbol in missing},
        "diagnostic_quotes": list(quotes.values()),
        "strategy_input_allowed": False, "orders_enabled": False,
        "real_time_verified": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("projection", type=Path)
    parser.add_argument("--symbols", help="진단 비교 종목; 게시 자료를 실시간 입력으로 승격하지 않음")
    args = parser.parse_args()
    raw = args.projection.read_bytes()
    if len(raw) > 16_384:
        parser.error("PROJECTION_TOO_LARGE")
    try:
        result = inspect_projection(json.loads(raw), required_symbols=(
            tuple(args.symbols.split(",")) if args.symbols else REQUIRED_SYMBOLS
        ))
    except (ValueError, TypeError, KeyError, AttributeError) as error:
        parser.exit(2, f"SNAPSHOT_REJECTED: {error}\n")
    result["projection_file_sha256"] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
